#!/usr/local/bin/php
<?

require("/home/httpd/html/projects/phpfeed/includes/phpFeed.inc.php");
$tmp = new phpFeed("/home/httpd/html/projects/phpfeed/includes/phpFeed_tables.config.xml");

foreach($tmp->ArrayActiveIndex() as $i)
        {
	$tmp->debug_on = 1;
	if ($tmp->NewsFeedFileIsCurrent($i) == 0) { $tmp->GetFreshNewsFeed($i); }
        }

?>