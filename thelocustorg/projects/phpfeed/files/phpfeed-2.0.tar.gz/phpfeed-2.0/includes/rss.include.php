<?

/* Php Rss Class
 * rss.php:
 *
 * Copyright (C) 2001 Olivier Dubroca
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 
 *
 * Rss Class requires the dom-xml php extension.
 *
 *
 * Updated 07/22/2002
 * ben wilson (ben@thelocust.org)
 * 
 * made compliant with DOM XML support with PHP 4.2.1
 *
 *
 *
 */


/* Additional classes */

class RssItem {
  var $title;
  var $link;
  var $desc;
  
  function RssItem ($title,$link,$desc) {
    $this->title = $title;
    $this->link = $link;
    $this->desc = $desc;
  }

  function toString() {
    echo "RssItem : \n\t title = $this->title \n\t link = $this->link\n";
  }
}  

class RssChannel {
  var $title;
  var $link;
  var $desc;

  function RssChannel ($title,$link,$desc) {
    $this->title = $title;
    $this->link = $link;
    $this->desc = $desc; 
  }

  function toString() {
    echo "RssChannel : \n\t title = $this->title \n\t link = $this->link\n\t desc = $this->desc\n";
  }
}

class RssImage {
  var $title;
  var $url;
  var $link;

  function RssImage($title,$url,$link) {
    $this->title = $title;
    $this->url = $url;
    $this->link = $link;
  }

  function toString() {
    echo "RssImage : \n\t title = $this->title \n\t link = $this->link\n\t url = $this->url\n";
  }
}

class Rss {
    
  var $rssDoc ;
  var $channel;
  var $image;
  var $items;
  var $count_item;
 

  function extract_rss_channel() {
    $title = $link = $desc = "";
    $root_node = domxml_root($this->rssDoc);
    
    $channel_node = $root_node->get_elements_by_tagname("channel");
    
    if ( sizeof($channel_node) ) {

      $title_node = $channel_node[0]->get_elements_by_tagname("title") ;
      if($title_node) {
	$title = $title_node[0]->get_content();
      }

      $link_node = $channel_node[0]->get_elements_by_tagname("link") ;
      if($link_node) {
	$link = $link_node[0]->get_content();
      }
      
      $desc_node = $channel_node[0]->get_elements_by_tagname("description") ;
      if($desc_node) {
	$desc = $desc_node[0]->get_content();
      }
    }
    $this->channel = new RssChannel($title,$link,$desc);
  }
  
  function extract_rss_image($nodePtr) {
    $title = $link = $url = "";
    $find = false;
    $image_node = $nodePtr->get_elements_by_tagname("image");
    if($image_node) {
      $find = true;
      $title_node = $image_node[0]->get_elements_by_tagname("title") ;
      if($title_node) {
	$title = $title_node[0]->get_content();
      }
      
      $link_node = $image_node[0]->get_elements_by_tagname("link") ;
      if($link_node) {
	$link = $link_node[0]->get_content();
      }
      
      $url_node = $image_node[0]->get_elements_by_tagname("url") ;
      if($url_node) {
	$url = $url_node[0]->get_content();
      }
    }
    $this->image = new RssImage($title,$url,$link);
    return $find;
  }
    
    
    
  function extract_rss_items($nodePtr) {

    $link = $desc = $title = "";
    $childs = $nodePtr->get_elements_by_tagname("item");

    $this->items = array();
    
    foreach ($childs as $node) {
	

      if($node->tagname == "item") {
	$title_node = $node->get_elements_by_tagname("title");
	//$title_node = xml_get_child_by_name($node,"title");
	if($title_node) {
	  if($title_node) { 
	    $title = $title_node[0]->get_content(); 
	  } 
 
	  $link_node = $node->get_elements_by_tagname("link") ; 
	  if($link_node) { 
	    $link = $link_node[0]->get_content(); 
	  }

	  $desc_node = $node->get_elements_by_tagname("description") ; 
	  if($desc_node) { 
	    $desc = $desc_node[0]->get_content(); 
	  }

	  array_push($this->items,new RssItem($title,$link,$desc));
	}
      }
    }
    return count($this->items);
  }
  
    
  function Rss($file) {
    //    $file = $this->channels_dir."/".$file;
    $this->rssDoc = domxml_open_file($file);
    if($this->rssDoc) {

      $this->extract_rss_channel();
      $root_node = $this->rssDoc->document_element();      


      if($this->extract_rss_image($root_node) == false) {
	$channel_node = $root_node->get_elements_by_tagname("channel"); 
	$this->extract_rss_image($channel_node[0]);
      }
      
      if(($this->item_count=$this->extract_rss_items($root_node))<1) {
	$channel_node = $root_node->get_elements_by_tagname("channel"); 
	$this->item_count = $this->extract_rss_items($channel_node[0]);
      }
      
    }
    else {
      echo "$file is not a valid xml file\n";
      exit();
    }
  }

  /* Accessors */ 
  function getChannel() {
  	return $this->channel;
  }

  function getImage() {
  	return $this->image;
  }

  function getItems() {
  	return $this->items;
  }

  /* Just for debug */
  function toString() {
    $this->channel->toString();
    $this->image->toString();
    for($i=0;$i<$this->item_count;$i++) {
      $this->items[$i]->toString();
    }
  }

}

?>

