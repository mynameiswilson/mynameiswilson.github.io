		
		<table>
			<tr>
				<td id="phpFeedItemTitle">
					<a id="phpFeedItemTitleLink"  href="<? echo $item_link ?>">
						<? echo $item_title ?>
					</a>
				<? if (sizeof($item_desc) > 0) { ?>
					<br>
					<span id="phpFeedItemDesc"><?echo $item_desc?></span>
					<? } ?>
				</td>
			</tr>
		</table>
