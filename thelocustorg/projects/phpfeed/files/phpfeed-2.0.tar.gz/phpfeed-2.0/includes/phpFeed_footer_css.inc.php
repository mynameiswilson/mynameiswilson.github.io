	<p id="phpFeedFooter">
		<? echo $filedate ?>
	</p>
  </div>
  <!-- END phpFeedItems -->
</div>
<!-- END phpFeed -->
