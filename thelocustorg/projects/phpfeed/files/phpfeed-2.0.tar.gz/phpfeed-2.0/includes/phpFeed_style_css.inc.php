<style type="text/css">

body
	{
	font: 11px/1.2 Verdana, Arial, Helvetica, sans-serif;
	font-size: 12;
	color: black;
	}

#phpFeed
  {
  }

#phpFeedImage
  {
  }


/* title of the Feed site, usually a link back to the site*/
#phpFeedTitle
  {
  border: 1px dotted;
  }

#phpFeedTitleLink
  {
  color: black;
  text-decoration: none;
  font-weight: bold;
  }
#phpFeedTitleLink:hover
  {
  text-decoration: underline;
  }

/* the p that has the feed description in it, e.g.
'news for nerds, stuff that matters' */
#phpFeedDesc
  {
  font: Arial;
  font-size: 10;
  color: gray;
  }


/*the div that encapsulates all "items"*/
#phpFeedItems
  {
  }

#phpFeedItemTitle
  {
   font: Arial;
   font-size: 11;
  }

#phpFeedItemTitleLink:visited {color: gray;}
#phpFeedItemTitleLink {color: black; text-decoration:none;}
#phpFeedItemTitleLink:hover {color: red;}

#phpFeedItemDesc
  {
  font-style: italic;
  color: gray;
  }

#phpFeedFooter
  {
   border: 1px dotted;
  }



</style>
