<?
/*
newsfeeds_header.inc.php
example!

essentially, there are 7 PHP variables passed to this page, or at least 7 that are accessible

 $image_link: the link that the IMAGE is linked to.
 $image_url : the image source URL - where to get the image!
 $image_title: i use this as the "alt" tag -- though you could do whatever.  slashdot's is "Slashdot"

 $channel_link  :  usually the site link
 $channel_title :  usually the site name
 $channel_description: description of the channel, often a tagline or desc of the site

 $feedindex	: index of the feed, useful for row/column setup
 $filetimestamp	: unix timestamp of the last time the feed was updated
 $filedate	: timestamp formatted like "23 Jun 2002 @ 03:12:23 PM"

 depending on the flags set in newsfeeds.config.xml, these variables will either be set, or NULL.  
 those if statements will fail if NULL, so they are shown when there is something in them.
*/

require_once($stylefilename);

?>
 
  <div id="phpFeed">
  	<!--START phpFeedImage-->
	<p id="phpFeedImage"><? if (strlen($image_url) >0) { ?><a href="<? echo $image_link ?>"><img src="<? echo $image_url ?>" border=0 alt="feed image"></a><? } ?></p>
  	<!--END phpFeedImage-->

  	<!--START phpFeedTitle-->
	<p id="phpFeedTitle">
		<? if ($channel_title) { ?>
			<a id="phpFeedTitleLink" href="<? echo $channel_link ?>" alt="<? echo $channel_title ?>">
				<? echo $channel_title ?>
			</a>
		<? } ?>

	<? if ( strlen($channel_description) > 0 ) { ?><br><span id="phpFeedDesc"><? echo $channel_description ?></span><? } ?>
	</p>
  	<!--END phpFeedTitle-->

	<!--START phpFeedItems-->
	<div id="phpFeedItems">
