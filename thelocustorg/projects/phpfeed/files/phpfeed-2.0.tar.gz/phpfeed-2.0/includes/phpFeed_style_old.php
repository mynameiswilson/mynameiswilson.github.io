<style type="text/css">

#phpFeed
  {
  }

#phpFeedImage
  {
   height:40px;
  }


/* title of the Feed site, usually a link back to the site*/
#phpFeedTitle
  {
  border: 1px dotted;
  }

#phpFeedTitleLink
  {
  font-size: 12;
  color: silver;
  text-decoration: none;
  }
#phpFeedTitleLink:hover
  {
  color: white;
  text-decoration: underline;
  }

/* the p that has the feed description in it, e.g.
'news for nerds, stuff that matters' */
#phpFeedDesc
  {
  font: Arial;
  font-size: 10;
  color: gray;
  }


/*the div that encapsulates all "items"*/
#phpFeedItems
  {
  padding: 0px;
  }

#phpFeedItemTitle
  {
   font: Arial;
   font-size: 10;
   padding: 0px;
  }

#phpFeedItemTitleLink:visited {color: gray;}
#phpFeedItemTitleLink {color: silver;}
#phpFeedItemTitleLink:hover {color: yellow;}

#phpFeedItemDesc
  {
  font-style: italic;
  color: gray;
  }

#phpFeedFooter
  {
   border: 1px dotted;
  }



</style>