	</td>
  </tr>
  <!-- END phpFeedItems -->
  <tr>
	<td id="phpFeedFooter">
		<? echo $filedate ?>
	</td>
  </tr>

  </table>
  <!--END phpFEED Table-->
</td>

<!-- END phpFeed -->
