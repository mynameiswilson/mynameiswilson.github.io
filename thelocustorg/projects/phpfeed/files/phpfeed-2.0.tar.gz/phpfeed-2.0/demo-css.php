<html>
<body>
<?
require("includes/phpFeed.inc.php");
$tmp = new phpFeed("/home/ben/public_html/phpfeed-2.0/includes/phpFeed_css.config.xml");

?>
<div width="50%">
  <p align="center" width="100%">
    <? echo $_SERVER['PATH_TRANSLATED']."!!" ?>
	<a href="http://thelocust.org/projects/phpfeed">phpFeed</a><br>
    <b>css-div layout example</b><br>
    (view <a href="demo-tables.php">tabled layout example</a>)<br>
    <br>view <a href="includes/phpFeed_css.config.xml">XML config file</a>
  </p>
  <br>
<?
  $tmp->showAllActiveNewsFeeds();   
?>
</div>
</body>
</html>
