<html>
<body>
<?
require("includes/phpFeed.inc.php");
$tmp = new phpFeed("/home/httpd/html/projects/phpfeed/includes/phpFeed_tables.config.xml");

?>
<div>
  <p align="center" width="100%">
    <b>tabled layout example</b><br>
    (view <a href="demo.php">css-div layout example</a>)<br>
    <br>view <a href="includes/phpFeed_tables.config.xml">XML config file</a>
  </p>
  <br>
  <table width="100%">
	<tr>
<?
  $feedsperrow = 3;
  foreach($tmp->ArrayActiveIndex() as $i)
	{
  	$tmp->showNewsFeed($i);
	if ( ($i%$feedsperrow-1 == 0) && ($i != 0) ) { echo "</tr><tr>"; }

	}   
?>
	</tr>
  </table>
</div>
</body>
</html>
