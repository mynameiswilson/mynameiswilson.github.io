#!/bin/sh
INSPATH="/usr/local/sysbk"
BINPATH="/usr/local/sbin/sysbk"

install(){
        rm -rf $INSPATH
        mkdir $INSPATH
        cp -R files/* $INSPATH
	cp README CHANGELOG COPYING.GPL $INSPATH
        chmod 640 $INSPATH/*
        chmod 750 $INSPATH/sysbk
        ln -fs $INSPATH/sysbk $BINPATH
}
if [ -d "$INSPATH" ]; then
	rm -rf $INSPATH
	install
else
	install
fi

echo ".: SysBK installed"
echo "Install path:    $INSPATH"
echo "Config path:     $INSPATH/conf.sysbk"
echo "Executable path: $BINPATH"
