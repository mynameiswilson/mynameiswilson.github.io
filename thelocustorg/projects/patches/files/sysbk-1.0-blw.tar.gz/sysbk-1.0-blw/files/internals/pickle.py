#!/usr/bin/python2.1

# This script will produce the python pickle needed for
# vhbackup to backup a site from the appliance administrator
import sys
import cPickle
import time
from vh3 import virthost
# Read the siteNNN from command line, we only check that there is
# an argument present, not if it is valid
try:
   site     = sys.argv[1]
except IndexError, msg:
   sys.stderr.write("Missing siteNNN argument\n")
   sys.exit(1)

# Set initial values, don't change these
xml_list = []
out_dict = {}
xml_dict = {'doctype':'backup','author':'appliance','type':'site'}
xml_dict['site'] = site
xml_list.append(virthost.create_site_xml(xml_dict))
out_dict['xml'] = xml_list
print "%s" % (cPickle.dumps(out_dict))
