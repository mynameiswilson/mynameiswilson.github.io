/*

 rblsmtpd with syslog                                          (v0.88c2)
 ====================
 This program is based on the rblsmtpd included in ucspi-tcp v0.88 that
 can be found at:
 
                   http://cr.yp.to/ucspi-tcp.html

 The current version of this modification and FAQ can be found at:

                   http://www.tjsi.com/rblsmtp/

 #######################################################################
 Original Copyright 2000 D. J. Bernstein

 Modifications Copyright 2003 David G. Perkins, T.J. Systems

 This program is free software.  Permission  to use,  copy,  modify  and
 distribute this software for  any purpose with or without fee is hereby
 granted, provided that  the above  copyright notice and this permission
 notice appear in all copies.

 This software is  distributed in the  hope that it will be useful,  but
 WITHOUT ANY WARRANTY. THE SOFTWARE IS PROVIDED "AS IS" AND T.J. SYSTEMS
 DISCLAIMS  ALL WARRANTIES  WITH REGARD  TO THIS  SOFTWARE INCLUDING ALL
 IMPLIED  WARRANTIES OF  MERCHANTABILITY  AND  FITNESS FOR  A PARTICULAR
 PURPOSE.  IN NO  EVENT SHALL  T.J. SYSTEMS BE LIABLE  FOR ANY  SPECIAL,
 DIRECT, INDIRECT,  OR CONSEQUENTIAL DAMAGES  OR ANY DAMAGES  WHATSOEVER
 RESULTING  FROM LOSS  OF USE, DATA OR PROFITS, WHETHER  IN AN ACTION OF
 CONTRACT, NEGLIGENCE OR OTHER  TORTIOUS  ACTION,  ARISING OUT OF  OR IN
 CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 #######################################################################

 This script was developed and tested on RedHat 7.2 & PSA v5.0.5 (RPM).
 Root privileges will be required to install this program. If you do 
 not have appropriate login qualifications, please contact your system
 administrator to do the installation for you (at their discretion, of
 course).

 New Usage: rblsmtpd [-v] ...
 
 -v: verbose mode - RBL server, rmote host IP, id and info logged.
 
 Comments and suggestions regarding the modification can be sent to: 

                        rblsmtpd@tjsi.com

 Changelog:
 
 2003-07-02: + Additional features modification (v0.88c2)
             + added the remote host id (if exists) to log
             + added the remote host info (if exists) to log
             + added the FAQ to the web site

 2003-06-28: + Original modification (v0.88c)

*/

#include "byte.h"
#include "str.h"
#include "scan.h"
#include "fmt.h"
#include "env.h"
#include "exit.h"
#include "sig.h"
#include "buffer.h"
#include "readwrite.h"
#include "sgetopt.h"
#include "strerr.h"
#include "stralloc.h"
#include "commands.h"
#include "pathexec.h"
#include "dns.h"

#include <syslog.h>

#define FATAL "rblsmtpd: fatal: "

void nomem(void)
{
  strerr_die2x(111,FATAL,"out of memory");
}
void usage(void)
{
  strerr_die1x(100,"rblsmtpd: usage: rblsmtpd [ -b ] [ -R ] [ -t timeout ] [ -v ] [ -r base ] [ -a base ] smtpd [ arg ... ]");
}

char *ip_env;
static stralloc ip_reverse;

#define LOG_PID "rblsmtpd"
int log_rejects=0;
char rbl_name[256];
char syslog_buf[256];
int syslog_priority = LOG_INFO;
int syslog_facility = LOG_MAIL;
char *remotehost_env;
char *remoteinfo_env;


void ip_init(void)
{
  unsigned int i;
  unsigned int j;

  ip_env = env_get("TCPREMOTEIP");
  if (!ip_env) ip_env = "";

  remotehost_env = env_get("TCPREMOTEHOST");
  if (!remotehost_env) remotehost_env = "-";
  if (str_len(remotehost_env) <= 0) remotehost_env = "-";

  remoteinfo_env = env_get("TCPREMOTEINFO");
  if (!remoteinfo_env) remoteinfo_env = "-";
  if (str_len(remoteinfo_env) <= 0) remoteinfo_env = "-";

  if (!stralloc_copys(&ip_reverse,"")) nomem();

  i = str_len(ip_env);
  while (i) {
    for (j = i;j > 0;--j) if (ip_env[j - 1] == '.') break;
    if (!stralloc_catb(&ip_reverse,ip_env + j,i - j)) nomem();
    if (!stralloc_cats(&ip_reverse,".")) nomem();
    if (!j) break;
    i = j - 1;
  }
}

unsigned long timeout = 60;
int flagrblbounce = 0;
int flagfailclosed = 0;
int flagmustnotbounce = 0;

int decision = 0; /* 0 undecided, 1 accept, 2 reject, 3 bounce */
static stralloc text; /* defined if decision is 2 or 3 */

static stralloc tmp;

void rbl(char *base)
{
  if (decision) return;
  if (!stralloc_copy(&tmp,&ip_reverse)) nomem();
  if (!stralloc_cats(&tmp,base)) nomem();
  if (dns_txt(&text,&tmp) == -1) {
    flagmustnotbounce = 1;
    if (flagfailclosed) {
      if (!stralloc_copys(&text,"temporary RBL lookup error")) nomem();
	  strcat(rbl_name,base);
      decision = 2;
    }
    return;
  }
  if (text.len)
    if (flagrblbounce) {
	  strcat(rbl_name,base);
      decision = 3;
    }
    else {
	  strcat(rbl_name,base);
      decision = 2;
    }
}

void antirbl(char *base)
{
  if (decision) return;
  if (!stralloc_copy(&tmp,&ip_reverse)) nomem();
  if (!stralloc_cats(&tmp,base)) nomem();
  if (dns_ip4(&text,&tmp) == -1) {
    flagmustnotbounce = 1;
    if (!flagfailclosed)
      decision = 1;
    return;
  }
  if (text.len)
    decision = 1;
}

char strnum[FMT_ULONG];
static stralloc message;

char inspace[64]; buffer in = BUFFER_INIT(read,0,inspace,sizeof inspace);
char outspace[1]; buffer out = BUFFER_INIT(write,1,outspace,sizeof outspace);

void reject() { 
  buffer_putflush(&out,message.s,message.len);
  if (log_rejects) {
  	strcat(syslog_buf,rbl_name);
  	strcat(syslog_buf," blocked ");
    strcat(syslog_buf,ip_env);
	strcat(syslog_buf," ");
	strcat(syslog_buf,remotehost_env);
	strcat(syslog_buf," ");
    strcat(syslog_buf,remoteinfo_env);
    openlog(LOG_PID,syslog_priority,syslog_facility); 
    syslog(syslog_priority,syslog_buf);
    closelog();
    log_rejects=0;
  }
}

void accept() { buffer_putsflush(&out,"250 rblsmtpd.local\r\n"); }
void greet()  { buffer_putsflush(&out,"220 rblsmtpd.local\r\n"); }
void quit()   { buffer_putsflush(&out,"221 rblsmtpd.local\r\n"); _exit(0); }
void drop()   { _exit(0); }

struct commands smtpcommands[] = {
  { "quit", quit, 0 }
, { "helo", accept, 0 }
, { "ehlo", accept, 0 }
, { "mail", accept, 0 }
, { "rset", accept, 0 }
, { "noop", accept, 0 }
, { 0, reject, 0 }
} ;

void rblsmtpd(void)
{
  int i;

  if (flagmustnotbounce || (decision == 2)) {
    if (!stralloc_copys(&message,"451 ")) nomem();
  }
  else
    if (!stralloc_copys(&message,"553 ")) nomem();

  if (text.len > 200) text.len = 200;
  if (!stralloc_cat(&message,&text)) nomem();
  for (i = 0;i < message.len;++i)
    if ((message.s[i] < 32) || (message.s[i] > 126))
      message.s[i] = '?';
  
  buffer_puts(buffer_2,"rblsmtpd: ");
  buffer_puts(buffer_2,ip_env);
  buffer_puts(buffer_2," pid ");
  buffer_put(buffer_2,strnum,fmt_ulong(strnum,getpid()));
  buffer_puts(buffer_2,": ");
  buffer_put(buffer_2,message.s,message.len);
  buffer_puts(buffer_2,"\n");
  buffer_flush(buffer_2);

  if (!stralloc_cats(&message,"\r\n")) nomem();

  if (!timeout)
    reject();
  else {
    sig_catch(sig_alarm,drop);
    alarm(timeout);
    greet();
    commands(&in,smtpcommands);
  }
  _exit(0);
}

main(int argc,char **argv,char **envp)
{
  int flagwantdefaultrbl = 1;
  char *x;
  int opt;

  ip_init();

  x = env_get("RBLSMTPD");
  if (x) {
    if (!*x)
      decision = 1;
    else if (*x == '-') {
      if (!stralloc_copys(&text,x + 1)) nomem();
      decision = 3;
    }
    else {
      if (!stralloc_copys(&text,x)) nomem();
      decision = 2;
    }
  }

  while ((opt = getopt(argc,argv,"bBcCvt:r:a:")) != opteof)
    switch(opt) {
      case 'b': flagrblbounce = 1; break;
      case 'B': flagrblbounce = 0; break;
      case 'c': flagfailclosed = 1; break;
      case 'C': flagfailclosed = 0; break;
      case 'v': log_rejects = 1; rbl_name[0] = '\0'; syslog_buf[0] = '\0'; break;
      case 't': scan_ulong(optarg,&timeout); break;
      case 'r': rbl(optarg); flagwantdefaultrbl = 0; break;
      case 'a': antirbl(optarg); break;
      default: usage();
    }

  argv += optind;
  if (!*argv) usage();

  if (flagwantdefaultrbl) rbl("rbl.maps.vix.com");
  if (decision >= 2) rblsmtpd();

  pathexec_run(*argv,argv,envp);
  strerr_die4sys(111,FATAL,"unable to run ",*argv,": ");
}

