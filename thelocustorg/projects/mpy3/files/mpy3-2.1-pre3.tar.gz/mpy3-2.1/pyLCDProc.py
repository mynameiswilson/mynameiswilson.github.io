#
# Name: pyLCDproc
# Desc: library for interfacing lcdproc in a simple manner
# Date: 11/30/2001
# Vers: 0.1
#
# Copyright (C) 2001 Ben Wilson
#  
#
# This library is free software; you #can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#
# python Module for LCDproc
# http://lcdproc.omnipontent.com
#
# MPy3
# the car mp3 suite
# http://mpy3.thelocust.org
# http://mpy3.sourceforge.net
# Contact: ben@thelocust.org / thelocust@users.sourceforge.net
#
# init it like so:
#	foo = pyLCDProc.open_lcd(HOST,PORT) (usually localhost and 13666)
#
# or, whatever port you are using.  scroll down to see all the functions.
# they are named appropriately, and I'm lazy.
#
#
#
# properties:
# 	cols - number of columns
# 	rows - number of rows
#	has_backlight - well?  does it?  0 for no, 1 for yes
#	contrast_backlight_on - when the backlight is on, set the contrast to this.
#	contrast_backlight_off - opposite of above. 
#		(the default contrast_backlight_on and off work well for my CrystalFontz,
#		a 4x20 634)
#

import os, tty, string, array, socket, re, sys, time, select, fcntl, FCNTL


class AutoFlush:
	def __init__(self, stream):
		self.stream = stream
		
	def write(self, text):
		self.stream.write(text)
		self.stream.flush()



class LCDProc:

	socket = ""
	contrast = ""
	backlight = ""
	rows = ""					# rows your lcd has
	cols = ""					# columns your lcd has
	has_backlight = ""			# if your lcd is backlit, 1, else 0

	debug_data_on = 0
	running = 0

	def __init__(self, host, port):

		# e.g. foo = pyLCDProc('localhost',13666)

		self.host = host
		self.port = port
		self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.sout = self.socket.makefile("rb")
		self.sin = self.socket.makefile("w+",0)

		
		ConnectionError = "Connect to " + str(self.host) + ":" + str(self.port) + " FAILED!"
					    
		try:
			self.socket.connect((self.host,int(self.port)))

		except socket.error:
			self.debug('Connect to ' + str(self.host) + ":" + str(self.port) + " FAILED!")
			raise ConnectionError		    

		self.socket.setblocking(0)


		self.debug('Introducing ourself to server')
		self.sin.write("hello\n")
		self.sin.flush()

		time.sleep(1)
		data = self.sout.readline()

		self.debug("THEDATA==> " + str(data))
		
		y = re.match('(\D+)\sLCDproc\s(\S+)\sprotocol\s(\S+)\slcd\swid\s(\d+)\shgt\s(\d+)\scellwid\s(\d+)\scellhgt\s(\d)',data)
		if y:
			self.lcdproc_version = y.group(2)
			self.lcdproc_protocol_version = y.group(3)
			self.cols = int(y.group(4))
			self.rows = int(y.group(5))
			self.cellwidth = y.group(6)
			self.cellheight = y.group(7)
			self.debug('Got Reply from LCDProc Server!')
			self.debug('LCDProc server version   : ' + str(self.lcdproc_version))
			self.debug('LCDProc protocol version : ' + str(self.lcdproc_protocol_version))
			self.debug('LCD rows      : ' + str(self.rows))
			self.debug('LCD columns   : ' + str(self.cols))
			self.debug('LCD cellwidth : ' + str(self.cellwidth) + 'px')
			self.debug('LCD cellheight: ' + str(self.cellheight) + 'px')

		else:
			self.debug('Saying Hello to LCDProc Server has Failed!')
			sys.exit()

		self.write('client_set name pylcdproc \n')

		self.debug("client set")
		
		self.write('screen_add myscreen \n')

		self.debug("screen add")

		self.write('screen_set myscreen heartbeat none \n')


		self.debug("screen set")

		for i in range(int(self.rows)):
			swidgadd = 'widget_add myscreen ' + str(i) + ' string\n'
			self.debug(swidgadd)
			self.write(swidgadd)

	def open_display(self):
		pass


	def write(self, text):
		self.debug(text)
		self.sin.write(text)
		self.sin.flush()
		
	
	def debug_data(self):
		if self.debug_data_on == 1:
			alldata = ""
			data = ""
			eof = 0
			while eof != 1:
				data = ""
				r,w,e = select.select([self.sout],[],[],0.2)
				if r:
					data = self.sout.readline()
					alldata = alldata + data
					
				if data == "": eof = 1
			
			self.sout.flush()
			return alldata
		


	def debug(self,text):
		print "pyLCDProc: " + str(text) + "\r"


	def shutdown(self):
		self.running = 0
		self.socket.close()

	def cls(self):
		# clear screen
		for i in range(int(self.rows)):
			self.blankline(i)
			
	
	def out(self, string_to_write):				# writes out a string to the current 
		# output string						# cursor position
		#self.socket.send('widget_set myscreen line0 ' + string_to_write)
		pass

	def hide_disp(self):						# hides the display
		pass

	def restore_disp(self):						# restores display
		pass

	def hide_cursor(self):						# hide cursor
		pass

	#### CURSOR RELATED #########################################################################

	def uline_cursor(self):						# sets cursor to the underline style
		pass

	def block_cursor(self):						# sets cursor to block style
		pass

	def invert_block_cursor(self):				# change to block cursor with no underline
		pass

	def backspace(self):						# destructive backspace
		pass

	def clear(self):						# form feed, clear display
		pass

	def cr(self):							# return cursor to leftmost space on row
		pass

	def crlf(self):							# figure it out!
               pass

	def cursor(self,col,row):				# sets cursor position to col, row
		pass

	##### BACKLIGHT CONTROLS ###############################################

	def backlight_on(self):
		pass

	def backlight_off(self):
		pass

	def set_backlight(self,set_level):
		pass

	def backlightup(self):
		pass
	
	def backlightdown(self):
		pass

	##### CONTRAST CONTROLS ###############################################
	def set_contrast(self,set_level):
		pass

	def contrastup(self):
		pass

	def contrastdown(self):
		pass




	def hbar(self,graph_index,style,start,end,length,row):
		self.socket.send('widget_set myscreen line'+str(row)+' hbar ' + str(start) + ' ' + str(row) + ' ' + str(length))

	def wrap_on(self):						# set line wrap on
		pass
			
	def wrap_off(self):						# set line wrap off
		pass

	def line(self, linenum, text): # display a line of text
		sline = 'widget_set myscreen ' + str(linenum) + ' 1 ' + str(linenum+1) + " {" + text + "}\n"
		self.write(sline)

	def cline(self, linenum, text):			# display a line of centered text
		text = string.center(string.strip(text),self.cols)
		self.line(linenum, text)

	def blankline(self, linenum):
		string = ""
		for i in range(self.cols):
			string = string + " "
		self.line(linenum,string)
		
