import os, select, struct
from time import sleep

j = os.open('/dev/js0',os.O_RDONLY|os.O_NONBLOCK)

while 1:
	r,w,e=select.select([j],[],[],0)
	if r:
		x = os.read(j,8)
		print struct.unpack('IhBB',x)
