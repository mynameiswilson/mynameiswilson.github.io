# pyjoy.py
#
# joystick input handler for mpy3

import select, os, struct
from time import sleep


class JoyInput:

	def __init__(self, device="/dev/js0"):

		print "JoyInput Initalizing"
		print "joystick device: " + str(device)

		self.device = device
		self.stop = 0

		self.joydev = os.open('/dev/js0',os.O_RDONLY|os.O_NONBLOCK)
		
	
	def start_input(self):
		
		while not self.stop:
			r, w, e = select.select([self.joydev], [], [])
			
			if r:
				x = os.read(j,8)
				print struct.unpack('IhBB',x)
