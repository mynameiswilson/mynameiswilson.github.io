#
# Name: pymix
# Desc: library for controlling aumix - a software mixer for *nix/*BSD
# Date: 1/01/2001
# Vers: 0.1.0
#
# Copyright (C) 2001 Ben Wilson
#  
#
# This library is free software; you #can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#	
#	http://mpy3.thelocust.org
#	http://mpy3.sourceforge.net
#	Contact: ben@thelocust.org / thelocust@users.sourceforge.net
#
#
# init it like so:
#
#	foo = pymix.mixer()
#
# you can also supply treble, bass, volume, pcm, cd, and increment on init, too.
#
# the increment is how much (out of 100) that the 'up' and 'down' commands change
# the setting.  aumix uses a 0 to 100 scale.


import os, sys

class mixer:

	def __init__(self,inittreble=60,initbass=60,initvolume=100,initpcm=60,initcd=60,increment=5):
		
		self.treble, self.bass, self.volume,\
		self.pcm, self.cd, self.increment = \
		int(inittreble), int(initbass), int(initvolume), 	\
		int(initpcm), int(initcd), int(increment)

		self.mutestatus = 0

		self.setbass(self.bass)
		self.settreble(self.treble)
		self.setvolume(self.volume)
		self.setpcm(self.pcm)
		self.setcd(self.cd)

	def setbass(self,setting):
		self.bass = int(setting)
		procstr = "aumix -b" + str(setting)
		os.system(procstr)

	def settreble(self,setting):
		self.treble = int(setting)
		procstr = "aumix -t" + str(setting)
		os.system(procstr)

	def setvolume(self,setting):
		self.volume = int(setting)
		procstr = "aumix -v" + str(setting)
		os.system(procstr)

	def setpcm(self, setting):
		self.pcm = int(setting)
		procstr = "aumix -w" + str(setting)
		os.system(procstr)

	def setcd(self, setting):
		self.cd = int(setting)
		procstr = "aumix -c" + str(setting)
		os.system(procstr)

	def bassup(self):
		if(self.bass <= (100-self.increment)):
			self.setbass(self.bass+self.increment)
			
	def bassdown(self):
		if(self.bass >= self.increment):
			self.setbass(self.bass-self.increment)

	def trebleup(self):
		if(self.treble <= (100 - self.increment)):
			self.settreble(self.treble + self.increment)
	
	def trebledown(self):
		if(self.treble >= self.increment):
			self.settreble(self.treble - self.increment)
	
	def volup(self):
		if(self.volume <= (100 - self.increment)):
			self.setvolume(self.volume + self.increment)
		
	def voldown(self):
		if(self.volume >= self.increment):
			self.setvolume(self.volume - self.increment)

	def pcmup(self):
		if(self.pcm <= (100-self.increment)):
			self.setpcm(self.pcm+self.increment)
		
	def pcmdown(self):
		if(self.pcm >= self.increment):
			self.setpcm(self.pcm-self.increment)

	def cdup(self):
		if(self.cd <= (100-self.increment)):
			self.setcd(self.cd+self.increment)
		
	def cddown(self):
		if(self.cd >= self.increment):
			self.setcd(self.cd-self.increment)

	def mute(self):
		if mutestatus:
			self.mutestatus = 0
			procstr = "aumix -v" + str(self.volume)
			os.system(procstr)
		else:
			self.mutestatus = 1
			procstr = "aumix -v0"
			os.system(procstr)


