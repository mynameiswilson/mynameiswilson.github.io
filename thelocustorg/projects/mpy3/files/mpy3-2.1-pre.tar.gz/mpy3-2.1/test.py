#!/usr/bin/python
import pyLCDProc
x = pyLCDProc.LCDProc('localhost',13666)
