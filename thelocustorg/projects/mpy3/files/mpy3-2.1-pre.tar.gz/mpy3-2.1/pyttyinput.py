# pyttyinput.py
#
# tty input grabber library for python!

import sys,  termios, tty,select
from time import sleep	

class ttyinput:

	character = ""
	running = 0

	def __init__(self):
		self.debug("Initializing")
		self.debug("Setting current TTY to RAW for Input")
		
		# set the tty to raw, so you don't need a newline to get the input.  
		self.settty(1)
		self.debug("End Initializing")


	def debug(self, text):
		print "pyTTYinput: " + text + "\r"
	
	def handle_input(self):
		self.debug("Starting Loop")
		
		self.running = 1
		while self.running:
				
			self.getinput()



	########################################################################
	# settty - set the stdin of whereever you are running this to raw input
	# so that input doesn't have to have a CRLF after it to be picked up by
	# read()
	#
	# raw - either 1 (for raw) or 0 to set it back
	#
	def settty(self,raw):
		tt = sys.stdin.fileno()			# get the file number of the STDIN

		if raw:									# if the passed arg "raw" is set to one, or true
			self.mode = termios.tcgetattr(tt)	# set an object parameter to the original state of the STDIN
			tty.setraw(tt,termios.TCSANOW)		# set the STDIN to raw (necessary for input handling, etc
		else:
			if self.mode:					# if "raw" is zero, or false
				termios.tcsetattr(tt, termios.TCSANOW,self.mode)	# then set the STDIN back to the original state
											# otherwise, you wouldn't see your text.


	########################################################################
	# getkey - HEY!  It's gets a key from STDIN
	# it will return that key, btw.
	# 
	def getinput(self):
		#tiny, tiny timeout value
		# 0 specifies a non-blocking poll, so we don't wait on the tty to get input
		
		r,w,e = select.select([sys.stdin],[],[],0)
		if r:
			# if we have something on the line
			# get the first character
      			ch = sys.stdin.read(1)
			
			# flush the rest of it
			termios.tcflush(sys.stdin.fileno(), termios.TCIFLUSH)	
			self.debug("Got Key: " + ch)
			# set the current character to the current character
			self.character = ch
		
			

	def shutdown(self):
		self.debug("Shutdown")		
		self.running = 0
		# set the tty to normal
		self.settty(0)
