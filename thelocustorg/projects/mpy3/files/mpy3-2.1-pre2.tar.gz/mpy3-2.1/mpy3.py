#!/usr/bin/env python
#
# Name: MPy3 
# Desc: MP3 Management System written in Python  
# Date: 11/28/2001
# Vers: 2.0
#
# Copyright (C) 2001 Ben Wilson
#
#This program is free software; you can redistribute it and/or
#modify it under the terms of the GNU General Public License
#as published by the Free Software Foundation; either version 2
#of the License, or (at your option) any later version.
#
#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#
#You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
#
# http://mpy3.thelocust.org
# http://mpy3.sourceforge.net
#
# Contact: ben@thelocust.org / thelocust@users.sourceforge.net
#

import sys, os, select, string
import time

import pyplaylist		# python library for MP3 list control

import FCNTL, fcntl
from fcntl import fcntl
from FCNTL import F_SETFL, F_SETFD, O_NONBLOCK
from threading import Thread

#MPy3 Class###############################################################################
class mpy3:

	init_state = "welcome"

	configs = {}
	
	running = 0

	keypress_timestamp = 0
	global_timestamp = 0
	temp_playlist = []

	mydisplaythread = ""
	myinputthread = ""
	myplayerthread = ""
	mymainthread = ""

        def __init__(self):

		self.global_timestamp = time.time()
		self.keypress_timestamp = time.time()
		self.configs = self.parseconfig()

                
                
		self.state = self.init_state
		self.running = 1
		self.moreinfo = 0
                
		# do setups for the different sections
		self.setup_display()
		self.setup_input()
		self.setup_player()
		self.setup_mixer()
		self.setup_list()

		self.handle_events()
                # startup the main mpy3 thread, handle_events
#		self.mymainthread = Thread(target=self.handle_events)
#		self.mymainthread.start()



	def shutdown(self):
		#upon shutdown, join all the threads

		# if we are using pyLCDemu -- it has it's own thread for
		# the window MainLoop -- KILL IT!
		if (self.configs['general']['display_type'] == "lcdemu"):
			self.mydisplaythread.join()

		self.mydisplay.shutdown()
		self.myinput.shutdown()
		self.myplayer.shutdown()
		
		self.myinputthread.join()
		self.myplayerthread.join()
		

	def debug(self, text):
		if self.configs['general']['debug'] == 1:
         		print "Mpy3: " + text + "\r"


	#######################################################################
	# parseconfig - parse the configuration file (whose filename is stated as an object parameter above)
	# and put all of the options into a dictionary called configs (also stated above)
	#

	def parseconfig(self):
                #parse that config file!

                #silly rabbit -- need to make this dynamic, so that when mpy3.py is called with
	        # mpy3.py myconf.conf, it will respect that one.
		config_file = "mpy3.conf"
		ConfigError = "Config File " + config_file + " NOT FOUND!"

                # import python's native Configuration Parser
		import ConfigParser
		configs = {}

	        # try to open the config file
		if(os.path.isfile(config_file)):	
			myparser = ConfigParser.ConfigParser()			# start an instance of the config parser
			myparser.read(config_file)					# read in the config file named above in config_file
		
			temp = {}	

			for section in myparser.sections():							# for each section
			
				for option in myparser.options(section):				# and each option for each section
					temp[option] = myparser.get(section,option)		
				
				configs[section] = temp				# assign a dictionary entry in the dictionary 'configs'
				temp = {}

                # otherwise raise an Error
		else:
			raise ConfigError			# no Config file?  bombs away!

                # return the "configs" list, which is a big ol' multidimensional config array
		return configs





	#######################################################################
	# setup_display - depending on the configuration, open the LCD or the X display

	def setup_display(self):
		
                # if using the X LCD emulator
		if (self.configs['general']['display_type'] == "lcdemu"):
                        import pyLCDemu
			self.mydisplay = pyLCDemu.LCDemu()

			# because of wxWindows need for the MainLoop to keep the display
			# up, we put this in it's own thread
			self.mydisplaythread = Thread(target=self.mydisplay.open_display)
			self.mydisplaythread.start()


		# if using the crystalfontz LCD
		elif (self.configs['general']['display_type'] == "crystalfontz"):
		        import pyCFontz
			self.mydisplay = pyCFontz.CFontz(self.configs['lcd']['port'])

		# if using the crystalfontz LCD
		elif (self.configs['general']['display_type'] == "lcdproc"):
		        import pyLCDProc
			self.mydisplay = pyLCDProc.LCDProc(self.configs['lcdproc']['hostname'],self.configs['lcdproc']['port'])


                # do initial setup for the display.
		self.mydisplay.cls()						# clear the screen of the LCD
		# set the contrast to the init_contrast from the config
		self.mydisplay.set_contrast(int(self.configs['lcd']['init_contrast']))

		# set backlight intensity to the init_backlight from cfg
		self.mydisplay.set_backlight(int(self.configs['lcd']['init_backlight']))	


	def setup_player(self):

		# for the moment, only rxaudio is supported, so init it, and start the thread
		
		self.mydisplay.out("Init rXaudio")

		import pyrx
		self.myplayer = pyrx.player()  		# create instance of the rxaudio MP3 player
		self.mydisplay.out(" [Ok]")
		self.mydisplay.crlf()

		self.myplayerthread =  Thread(target=self.myplayer.handle_audio)
		self.myplayerthread.start()

	def setup_input(self):
		# depending on the input type, open the inpyt and thread it
		if ( self.configs['inputconfig']['type'] == "tty" ):
			import pyttyinput
			self.myinput = pyttyinput.ttyinput()
		elif ( self.configs['inputconfig']['type'] == "joystick"):
			import pyjoyinput
			self.myinput = pyjoyinput.JoyInput()
		else:
			pass

		self.myinputthread = Thread(target=self.myinput.handle_input)
		self.myinputthread.start()

		
	def setup_mixer(self):
		import pymix
		self.mymixer = pymix.mixer(	self.configs['mixer']['inittreble'], \
									self.configs['mixer']['initbass'],\
									self.configs['mixer']['initvolume'],\
									self.configs['mixer']['initpcm'],\
									self.configs['mixer']['initcd'],\
									self.configs['mixer']['increment'])

	def setup_list(self):
		import pyplaylist
		self.mylist = pyplaylist.playlist()			# create instance of the playlist module
		self.mylist.compile_masterlist(self.configs['general']['mp3dir'])	
							# populate list.mp3list with files from that directory (recursively)
	        self.mylist.set_playlist_as_list()



	########################################################################
	# getkey - HEY!  It's gets a key from STDIN
	# it will return that key, btw.
	# 
	def getkey(self):

		#get the current character from the input module
		x = self.myinput.character

		#clear the character so we don't keep getting the same one OVER and OVER again
		self.myinput.character = ""

		#return the character
		return x
	
	def handle_events(self):
		# uh.  i'm lazy.  i don't like typing self.
		myplayer = self.myplayer
		mylist = self.mylist
		mydisplay = self.mydisplay
		mymixer = self.mymixer
		configs = self.configs


		if self.state == "welcome":
			self.state_welcome("enter","")
		elif self.state == "main":
			self.state_main("enter","")

		while (self.running == 1):
			# get character from input
			x = self.getkey()	


			# if the key isn't a blank string, then reset the keypress timestamp (the last time a key was pressed)
			# to the current time.  used for timeout purposes.
			if x != "":
				self.debug("resetting keypress timestamp current=> " + str(self.keypress_timestamp) )
				self.keypress_timestamp = time.time()

			#otherwise, if the KEYPRESS timeout has occurred, and the state ISN'T in "PLAY", then turn it back to play.
			#this way, if you hit the "menu" key, it will revert back to the "play" state.  like a REAL CD player.
			else:
				if ( (time.time()-int(configs['player_options']['keypress_timeout']) > (self.keypress_timestamp)) and self.state != "play" ):
					self.debug("KEYPRESS TIMEOUT! keypress=>" + str(self.keypress_timestamp) + "  currenttime=>" + str(time.time()) )
					self.state_play("enter","")
					


			# HANDLE KEYS
			# first, we see if the key is a global, and if so, handle it
			# otherwise, depending on the current state we are in, we send the
			# key to that state, and it handles it.
			
			### BEGIN GLOBALS ###
#			if x == configs['global']['quit']:
#				self.state_shutdown("enter","")
#				self.running = 0
#
#			elif x == configs['global']['main']:
#				self.state_main("enter","")
#
			### BEGIN STATES ###

			if self.state == "main":
				self.state_main("key",x)
			elif self.state == "play":
				self.state_play("key",x)
			elif self.state == "config":
				self.state_config("key",x)
			elif self.state == "playlist":
				self.state_playlist("key",x)
			elif self.state == "audio":
				self.state_audio("key",x)
			elif self.state == "display":
				self.state_display("key",x)



			# this is to handle a song reaching the end, and then forwarding to the next
			# song.  if it has reached the "End Of File", then move to the next song
			if myplayer.state == "eof":
				if self.state == "play": mydisplay.cls()
				self.nextsong()				

		# if we've exited the loop (running no longer is equal to ==1, then shutdown.
		self.shutdown()


        # basic player functions
	
	def play(self):
		# this makes the player play the current file on the playlist.
		# if the song is playing, and then "play" is hit again, it starts
		# playing the song from the beginning.
		myplayer = self.myplayer
		mylist = self.mylist
		self.debug("PLAY")
		myplayer.play(mylist.current_file())
		
	def nextsong(self):
		mylist = self.mylist
		myplayer = self.myplayer
		self.debug("NEXT SONG")
		mylist.next()
		self.play()
	
	def prevsong(self):
		mylist = self.mylist
		myplayer = self.myplayer
                self.debug("PREVIOUS SONG")
		mylist.prev()
		self.play()

	def firstsong(self):
		mylist = self.mylist
		myplayer = self.myplayer
		self.debug("FIRST SONG")
		mylist.first()
		self.play()




	# STATES
	# 
	# a "state" is essentially a display, though it also controls how keystrokes are handled.
	# there are a number of states -- play, main, welcome, playlist, config, audio, etc
	# they all have a display_STATENAME function as well, and that is called at some point in the
	# state.
	#
	# each state has an "interrupt" and "key"
	# if a state is just being loaded, then the interrupt passed should be "enter", and this allows
	# you to handle some first-run things, like initializing variables, etc.  at this time, self.state should be
	# set to the state name, so that when handle_events is called again, it know which state to send the key to.  
	#
	# otherwise, if we are in that state already,
	# the interrupt passed is "key", which lets us know a key is being passed to the state.  the parameter "key" is where
	# the key value is.

	def state_welcome(self,interrupt,key):
		myplayer = self.myplayer
		mylist = self.mylist
		mydisplay = self.mydisplay
		configs = self.configs		

		#duh.  intro screen.  if init_state is set to "welcome", then it comes here, and then enters the "main" state.
		#this could become configurable in the future, as to which state it enters, etc.
                self.debug("WELCOME state")

		mydisplay.cls()
		mydisplay.line(0,"Welcome to....")
		mydisplay.line(1,"MPy3")
		mydisplay.line(2," by ")
		mydisplay.line(3,"Ben Wilson")
		
		#snooze for a bit, so you can bask in the glory.
		time.sleep(2.0)

		# check some initial config options
		if (int(configs['player_options']['shuffle_on_start'])): mylist.randomize()
		if (int(configs['player_options']['play_on_start'])): self.play()

		# goto the main menu
		self.state_main("enter","")


	def state_main(self,interrupt,key):
			if (interrupt == "enter"):
			        self.debug("MAIN state")
				self.state = "main"
				self.display_main()

			# handle KEY interrupt.  in state_main, this handles
			# the menu keys
			elif (interrupt == "key"):
				if (key == self.configs['main']['state_play']):
					self.state_play("enter","")
				elif (key == self.configs['main']['state_config']):
					self.state_config("enter","")
				elif (key == self.configs['main']['state_audio']):
					self.state_audio("enter","")
				elif (key == self.configs['main']['state_display']):
					self.state_display("enter","")
				elif (key == self.configs['main']['state_playlist']):
					self.state_playlist("enter","")
				elif (key == self.configs['main']['quit']):
					self.state_shutdown("enter","")

	
	def display_main(self):
		configs = self.configs
		myplayer = self.myplayer
		mylist = self.mylist
		mydisplay = self.mydisplay

		# display the menu options.
		# note that it displays the key needed for each dynamically, so if you set up the menu keys
		# to be a,b,c,d etc it would show up as such:
		#
		# a.play  b.config
		# c.audio d.display
		#
		#
		mydisplay.cls()
		mydisplay.cline(0,"main menu")
		mydisplay.cline(1,str(configs['main']['state_play']) + ". play  " + str(configs['main']['state_config']) + ". config")
		mydisplay.cline(2,str(configs['main']['state_audio'])+ ". audio " + str(configs['main']['state_display']) + ". display")
		mydisplay.cline(3,str(configs['main']['state_playlist'])+ ". plist " + str(configs['main']['quit']) + " to quit")


	def state_shutdown(self,interrupt,key):
		myplayer = self.myplayer
		mylist = self.mylist
		mydisplay = self.mydisplay
		myinput = self.myinput

		# shutdown the program

                self.debug("SHUTDOWN")
		
		self.state = "shutdown"
		self.playing = 0
		self.running = 0

		myplayer.shutdown()
		myinput.shutdown()

		mydisplay.cls()
		mydisplay.cline(0,"thanks for using")
		mydisplay.cline(1,"MPy3")
		mydisplay.cline(2," by ")
		mydisplay.cline(3,"Ben Wilson")
		time.sleep(3.0)
		mydisplay.cls()
		
		self.shutdown()

	def state_play(self,interrupt,key):
			myplayer = self.myplayer
			mylist = self.mylist
			mydisplay = self.mydisplay
			mymixer = self.mymixer

			self.display_play()

			if (interrupt == "enter"):
			        self.debug("PLAY state")
				self.state = "play"
				mydisplay.cls()
				self.display_play()

			# handle keys
			elif (interrupt == "key"):
								
				if(key == self.configs['play']['play']):
					self.play()
										
				elif(key == self.configs['play']['pause']):
					myplayer.pause()

				elif(key == self.configs['play']['stop']):
					myplayer.stop()
					
				elif(key == self.configs['play']['prev']):
					mydisplay.cls()
					self.prevsong()

				elif(key == self.configs['play']['next']):
					mydisplay.cls()
					self.nextsong()


				elif(key == self.configs['play']['random']):
					mylist.randomize()
				
				# if the current song has more info (ie. album name, comments),
				# set the moreinfo bit to 1
				elif(key == self.configs['play']['moreinfo']):
					if (self.moreinfo == 0):
							self.moreinfo = 1
							mydisplay.cls()
					else:
							self.moreinfo = 0 
							mydisplay.cls()
		
			self.display_play()

			
	def display_play(self):
		myplayer = self.myplayer
		mylist = self.mylist
		mydisplay = self.mydisplay		

		# myplayer.newinfo lets us know if there is new information
		# to display.  this isn't needed using pyLCDemu, but for an
		# LCD, it is necessary, as MPy3 calls display_play so often that
		# the LCD can't catch up, and it's inefficient.  hence, this causes
		# the lcd to update only when necessary.
		
		if myplayer.newinfo == 1 or self.moreinfo == 1:

			# initialize the lines
			# note well that this wouldn't work so hot with a 2 line lcd.  i'll have to make some
			# changes to this to support such things, based on configs['lcd']['rows']
			line0 = mylist.songname
			line1 = mylist.artist
			line2 = ""
			line3 = ""

			# if the moreinfo bit is true, then show the more info instead of the standard
			# bottom two lines
			if (self.moreinfo == 1):
				line2 = mylist.album
				line3 = mylist.comment

			# show the standard bottomw two lines
			else:
				# show currentsongindex/total number of songs (i.e. 2/10)
				line2 = str(mylist.index+1) + "/" + str(len(mylist.playlist)) + " " 


				# show time remaining or time elapsed?
				if (int(self.configs['player_options']['show_time_remaining'])==1):
						line2 = line2 + "-" + str(myplayer.minremain)+":"+str(myplayer.secremain)
				else:
						line2 = line2 + str(myplayer.min)+":"+str(myplayer.sec)

				# bitrate and sampling freq
				line3 = myplayer.bitrate + "kbps " + myplayer.frequency + "kHz"

				# if there is moreinfo to be had -- the comment/album fields in the id3v1 tag
				# then put a little "i" at the end of the bottom line to let the user know.
				if (len(mylist.album)>0 or len(mylist.comment)>0):
					line3 = line3 + " i"

			# show the stuff
			mydisplay.line(0,line0)
			mydisplay.line(1,line1)
			mydisplay.line(2,line2)
			mydisplay.line(3,line3)

			# let the player know we've shown the stuff (so when it gets new stuff, we will know)
			myplayer.newinfo = 0



	def state_playlist(self,interrupt,key):
		myplayer = self.myplayer
		mylist = self.mylist
		mydisplay = self.mydisplay
		mymixer = self.mymixer
		configs = self.configs
		

                if (interrupt == "enter"):
			        self.debug("PLAYLIST state")
				self.state = "playlist"

				# init variables.
				#
				# top_index - what filename is at the top of the display?
				# cursor_index - what rows is the cursor on on the display? (between 0 and 3 for a 4 row disp)
				# depth_index - how deep have we recursed?
				# index_begin - 
				#
				self.playlist_top_index = 0
				self.playlist_cursor_index = 0
				self.playlist_depth_index = 0
				self.playlist_index_begin = 0
				self.playlist_index_end = 0

                                # uh, to save display space, i tried to have the cursor appear/disappear
                                # but that requires some timing issues, and it really wasn't worth it at the moment
                                # maybe later
				self.playlist_cursor_blink = 0
				self.playlist_cursor_blink_timer = 0

                                # setup the current directory
				self.playlist_current_dir = configs['general']['mp3dir']

                                # get the directory listing
				self.playlist_dirlist = os.listdir(self.playlist_current_dir)

                                #clear disp, show the playlist screen
				mydisplay.cls()
				self.display_playlist()
				

		elif (interrupt == "key"):

			
			if(key == self.configs['playlist']['up'] ):
				self.debug("playlist: UP")

				# if the current cursor position is at the top (0 in the list, and row 0 on the lcd)
				# then obviously we can't go up further
				if (self.playlist_cursor_index + self.playlist_top_index) == 0 :
					pass
				# other wise,
				else:
					# if the cursor is at the top of the LCD, then on "up", move the top index of the list
					# up just one
					if self.playlist_cursor_index == 0 :
						self.playlist_top_index = self.playlist_top_index - 1
					else:
						self.playlist_cursor_index = self.playlist_cursor_index - 1


			elif(key == self.configs['playlist']['down'] ):
				self.debug("playlist: DOWN")
				if (self.playlist_cursor_index + self.playlist_top_index) == len(self.playlist_dirlist) - 1 :
					pass
				else:
					if self.playlist_cursor_index == int(configs['lcd']['rows']) - 1 :
						self.playlist_top_index = self.playlist_top_index + 1
					else:
						self.playlist_cursor_index = self.playlist_cursor_index + 1

			elif(key == self.configs['playlist']['pageup'] ):
				self.debug("playlist: PAGEUP")
				
				if (self.playlist_top_index - int(configs['lcd']['rows']) < 0):
					self.playlist_cursor_index = 0
					self.playlist_top_index = 0
				else:
					self.playlist_top_index = self.playlist_top_index - int(configs['lcd']['rows'])


			elif(key == self.configs['playlist']['pagedown'] ):
				self.debug("playlist: PAGEDOWN")

				# if the current "top index" plus the number of rows on the lcd are greater than
				# the end of the list, then we can't go down any further.
				if (self.playlist_top_index + int(configs['lcd']['rows'])) > len(self.playlist_dirlist) - 1 :
					self.playlist_cursor_index = len(self.playlist_dirlist) - self.playlist_top_index - 1
				else:
					self.playlist_top_index = self.playlist_top_index + int(configs['lcd']['rows'])

				
			elif(key == self.configs['playlist']['tag'] ):
				self.debug("tagged " + str(self.playlist_dirlist[self.playlist_top_index + self.playlist_cursor_index]))
                                # attempt to add the filename to the temp playlist
				mylist.add_file_to_templist(self.playlist_current_dir + "/" + self.playlist_dirlist[self.playlist_top_index + self.playlist_cursor_index])
				
			elif(key == self.configs['playlist']['open'] ):
                                # check to see if the file we are attempting to "opeN" is in fact a directory
				if os.path.isdir(self.playlist_current_dir + "/" +  self.playlist_dirlist[self.playlist_top_index + self.playlist_cursor_index] ):
                                    # if so, then set the current directory to the directory we've opened,
                                    self.playlist_current_dir = self.playlist_current_dir + "/" + self.playlist_dirlist[self.playlist_top_index + self.playlist_cursor_index]
                                    # set the directory listing to the listing of the current directory
                                    self.playlist_dirlist = os.listdir(self.playlist_current_dir)
                                    
                                    #set the top_index to the top, and the cursor to the top
                                    self.playlist_top_index = 0
                                    self.playlist_cursor_index = 0
                                    self.debug("OPENING DIR -->" + self.playlist_current_dir)

		      	elif(key == self.configs['playlist']['close']):
				# make sure we aren't trying to go up PAST the initial MP3 directory
				if (self.playlist_current_dir != configs['general']['mp3dir']):
					splitdir = string.split(self.playlist_current_dir, "/")
					self.playlist_current_dir = string.join(splitdir[0:len(splitdir)-1],"/")
					self.playlist_dirlist = os.listdir(self.playlist_current_dir)
				
		      	elif(key == self.configs['playlist']['selectall']):
				mylist.set_templist_as_list()
				
			elif(key == self.configs['playlist']['finish'] ):
				mylist.set_templist_as_playlist()
				self.firstsong()
				self.state_play("enter","")
				
			elif(key == self.configs['playlist']['clear'] ):
				mylist.clear_templist()


			# so that we don't have to keep refreshing an un-chaning playlist screen,
			# we only call display_playlist if a key has in fact been sent to us, or
			if ( len(key) ):
				self.display_playlist()
			

	def display_playlist(self):
		mydisplay = self.mydisplay
		mylist = self.mylist
		configs = self.configs

                # only show enough files on the display as there are rows.
		for x in range(int(configs['lcd']['rows'])):
                        # the cursor, in this case, is a string that this prepended to each filename in
                        # playlist_dirlist -- used to convey the cursor location, and whether the file is a
                        # directory or an mp3.
			cursor = ""
			
			# for each level of recursive depth, put another period in front on the filename
			for i in range(self.playlist_depth_index+1):
				cursor = cursor + "."

			# make sure that we are not attempting to pull back a filename for an index in list that isn't out of range
			# and if we are, then just show a blank line.
			if (self.playlist_top_index + x < len(self.playlist_dirlist)):


				# if the track currently exists in our "temp playlist", then put an
				# asterisk next to it.  we need the "try/except" here, because if we
				# do a "list.index(var)" and 'var' doesn't exist in the list, then
				# it throws a value error (hence, except ValueError)
				try:
                                        # make a full path from the current_dir name, and the name of the file
					fullfilename = self.playlist_current_dir + "/" + self.playlist_dirlist[self.playlist_top_index + x]
					files_tagged_under_dir = 0

					# if it is a directory
					if os.path.isdir( fullfilename ):
						for z in range( len(mylist.templist) ):
                                                    
							# find the number of files tagged under the directory
							if string.find(mylist.list[mylist.templist[z]], fullfilename) > -1 :
								       files_tagged_under_dir = files_tagged_under_dir + 1

                                                # if there are files tagged under the directory, set the cursor for this file
                                                # to "*" (the tagged sign)
						if files_tagged_under_dir > 0 :
							cursor = cursor + "*"

                                        # if the file isn't a directory
					else:
						# get the index of the current file in the master list
						y = mylist.list.index( fullfilename )

						# check to see if that index is in the playlist
                                                # and if it is, set the cursor to the tagged sign
						if mylist.templist.index(y) > -1 :
							cursor = cursor[0:len(cursor)-1] + "*"
						
				

				except ValueError:
					pass

                                # if the file is a directory, show a "+" in front of it
				if os.path.isdir(self.playlist_current_dir + "/" +  self.playlist_dirlist[self.playlist_top_index + (x)]):
					cursor = cursor + "+"

                                # if the cursor is on this line, then put the cursor ">" in front of it
				if self.playlist_cursor_index == x:
					cursor = ">" + cursor

                                # finally, show the line with the cursor and filename
				filename = self.playlist_dirlist[self.playlist_top_index + (x)]
				mydisplay.line(x,cursor + filename)
			else:
				mydisplay.blankline(x)






	def state_audio(self,interrupt,key):
		mymixer = self.mymixer
		mydisplay = self.mydisplay
		configs = self.configs

		self.state == "audio"

		if (interrupt == "enter"):
                                self.debug("AUDIO state")
				self.state = "audio"
				self.display_audio()
		
		elif (interrupt == "key"):
		
			if(configs[self.state].has_key('voldown') and key == str(configs['audio']['voldown'])):
				mymixer.voldown()

			elif(configs[self.state].has_key('voldefault') and key == str(configs['audio']['voldefault'])):
				mymixer.setvolume(configs['mixer']['initvolume'])

			elif(configs[self.state].has_key('volup') and key == str(configs['audio']['volup'])):
				mymixer.volup()

			elif(configs[self.state].has_key('trebledown') and key== configs['audio']['trebledown']):
				mymixer.trebledown()

			elif(configs[self.state].has_key('trebledefault') and key == str(configs['audio']['trebledefault'])):
				mymixer.settreble(configs['mixer']['inittreble'])

			elif(configs[self.state].has_key('trebleup') and key == configs['audio']['trebleup']):
				mymixer.trebleup()

			elif(configs[self.state].has_key('bassdown') and key == configs['audio']['bassdown']):
				mymixer.bassdown()

			elif(configs[self.state].has_key('bassdefault') and key == str(configs['audio']['bassdefault'])):
				mymixer.setbass(configs['mixer']['initbass'])

			elif(configs[self.state].has_key('bassup') and key == configs['audio']['bassup']):
				mymixer.bassup()

			if(key!=""):
				self.display_audio()
		
	

	def display_audio(self):
		mydisplay = self.mydisplay
		mymixer = self.mymixer

		mydisplay.cls()
		mydisplay.cline(0,"audio settings")

                # uh.  i don't think hbars work in pyLCDemu.  maybe they do.
		mydisplay.hbar(1,60,3,19,mymixer.volume,1)
		mydisplay.hbar(2,60,3,19,mymixer.treble,2)
		mydisplay.hbar(3,60,3,19,mymixer.bass,3)

		mydisplay.line(1,"vol " + str(mymixer.volume))
		mydisplay.line(2,"tre " + str(mymixer.treble))
		mydisplay.line(3,"bas " + str(mymixer.bass))


		
	def state_display(self,interrupt,key):
		mydisplay = self.mydisplay
		configs = self.configs

		self.state == "display"

		if (interrupt == "enter"):
		                self.debug("DISPLAY state")
				self.state = "display"
				self.display_display()
		
		elif (interrupt == "key"):
		
			if(configs[self.state].has_key('contrastdown') and key==configs['display']['contrastdown']):
				mydisplay.contrastdown()

			elif(configs[self.state].has_key('contrastdefault') and key==configs['display']['contrastdefault']):
				mydisplay.set_contrast(configs['display']['contrastdefault'])

			elif(configs[self.state].has_key('contrastup') and key==configs['display']['contrastup']):
				mydisplay.contrastup()

			elif(configs[self.state].has_key('backlightdown') and key==configs['display']['backlightdown']):
				mydisplay.backlightdown()

			elif(configs[self.state].has_key('backlightdefault') and key==configs['display']['backlightdefault']):
				mydisplay.set_backlight(configs['display']['backlightdefault'])

			elif(configs[self.state].has_key('backlightup') and key==configs['display']['backlightup']):
				mydisplay.backlightup()

			elif(configs[self.state].has_key('backlight_on') and key==configs['display']['backlight_on']):
				mydisplay.backlight_on()

			elif(configs[self.state].has_key('backlight_off') and key==configs['display']['backlight_off']):
				mydisplay.backlight_off()

			if(key!=""):
				self.display_display()
		
	

	def display_display(self):
		mydisplay = self.mydisplay

		mydisplay.cls()
		mydisplay.cline(0,"disp settings")

		mydisplay.hbar(1,60,3,19,mydisplay.contrast,1)
		mydisplay.hbar(2,60,3,19,mydisplay.backlight,2)

		mydisplay.line(1,"con" + str(mydisplay.contrast))
		mydisplay.line(1,"bck" + str(mydisplay.backlight))


		if(mydisplay.backlight > 0):
			mydisplay.cline(3,"backlight is on")
		else:
			mydisplay.cline(3,"backlight is off")


	def state_config(self, interrupt, key):
		mydisplay = self.mydisplay
		mylist = self.mylist
		configs = self.configs

		if (interrupt == "enter"):
		        self.debug("CONFIG state")
              		self.state = "config"
			self.display_config()

		
		elif (interrupt == "key"):
			if(key == self.configs['config']['random']):
					mylist.randomize()
		
			self.display_config()
		

	def display_config(self):
		mydisplay = self.mydisplay
		mylist = self.mylist		
		
		mydisplay.cls()

		if (int(mylist.israndom)): 
			randstatus = "on"
		else: 
			randstatus = "off"

		line0 = "config"
		line1 = "random play: " + randstatus


		mydisplay.cline(0,line0)
		mydisplay.line(1,line1)
		


#END CLASS###############################################################################


mympy3 = mpy3()


