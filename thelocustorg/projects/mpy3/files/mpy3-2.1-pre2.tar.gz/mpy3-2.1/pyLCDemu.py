import string
from threading import Thread
from time import sleep

class LCDemu:
	
	need_update = 0
	running = 0
	debug = 1
	
	def __init__(self,rows=4,cols=20):

		self.debug("Initializing")
		self.rows = rows
		self.cols = cols
		self.curx = 1
		self.cury = 1
		self.waiting = 1
		self.lines = {}
		self.labels = {}


		for x in range(self.rows):
			self.lines[x] = "line" + str(x)	
			print self.lines[x] + "line " + str(x)

	def debug(self, text):
		if self.debug:
			print "pyLCDemu: " + str(text) + "\r"


	def shutdown(self):
		self.debug("Shutdown")
		self.running = 0
		self.frame.Close()
		
		               
    	def open_display(self):
    		self.debug("importing wxPython")
		from wxPython.wx import *
		
		self.app = wxPySimpleApp()
		
		winx = 640
		winy = 480
		
		self.frame = wxFrame(None, -1, "MPy3", size=(winx,winy))
		self.frame.Show(true)
		font = wxFont(24, wxMODERN, wxNORMAL, wxBOLD, false)
		
		#self.txt = wxTextCtrl(self.frame, -1,"hello",(x*50,x*50),wxSize(600,400),wxTE_MULTILINE | wxHSCROLL)
		#self.txt.SetFont(font)
		
		for x in range(self.rows):
			self.debug("updating row " + str(x))
			self.labels[x] = wxStaticText(self.frame, -1, str(x),wxPoint(0,x*24))
			self.labels[x].SetFont(font)

		self.debug("Entering MainLoop")
		self.MainLoop()
		self.debug("Exiting MainLoop")
		return true
    
	def MainLoop(self):
		self.running = 1
		while (self.running):
			while self.app.Pending():
                		self.app.Dispatch()
                	if(self.need_update == 1):
				self.update_window()
				sleep(0.02)
			self.app.ProcessIdle()

	def update_window(self):
		newtext = ""
		
		for x in range(self.rows):
			self.labels[x].SetLabel(self.lines[x])
			self.labels[x].Refresh()

		self.need_update = 0

    		
	def out(self,text):
		pass
		
	

	def cls(self):			# clears the screen
		for x in range(self.rows):
			self.lines[x] = ""
		self.need_update = 1


	def hide_disp(self):						# hides the display
		pass

	def restore_disp(self):						# restores display
		pass

	def hide_cursor(self):						# hide cursor
		pass

	#### CURSOR RELATED #########################################################################

	def uline_cursor(self):						# sets cursor to the underline style
		pass

	def block_cursor(self):						# sets cursor to block style
		pass

	def invert_block_cursor(self):				# change to block cursor with no underline
		pass

	def backspace(self):						# destructive backspace
		pass

	def lf(self):							# line feed (move down one line), if scroll is on
		pass				# and at the bottom line, the display will scroll up,
										# leaving bottom line blank.

	def delete(self):						# delete in place
		pass

	def clear(self):						# form feed, clear display
		pass

	def cr(self):							# return cursor to leftmost space on row
		pass

	def crlf(self):							# figure it out!
		pass
		

	def cursor(self,col,row):				# sets cursor position to col, row
		self.txt.SetInsertionPoint(5)

	##### BACKLIGHT CONTROLS ###############################################

	def backlight_on(self):
		# turns backlight to 100, contrast to contrast_backlight_on setting
		if(int(self.has_backlight)):
			self.set_backlight(100)
			self.set_contrast(self.contrast_backlight_on)

	def backlight_off(self):
		# turns backlight to 0, contrast to contrast_backlight_off setting
		if(int(self.has_backlight)):
			self.set_backlight(0)
			self.set_contrast(self.contrast_backlight_off)

	def set_backlight(self,set_level):
		pass

	def backlightup(self):
		if(int(self.has_backlight)):
			if(self.backlight <= 96):
				self.set_backlight(self.backlight + 4)

	def backlightdown(self):
		pass

	##### CONTRAST CONTROLS ###############################################
	def set_contrast(self,set_level):
		pass

	def contrastup(self):
		if(self.contrast <= 96):
			self.set_contrast(self.contrast + 4)

	def contrastdown(self):
		if(self.contrast >= 4):
			self.set_contrast(self.contrast - 4)


	############## MISC ##########################

	def hbar(self,graph_index,style,start,end,length,row):
		# horizontal bar graph
		self.out('%c%c%c%c%c%c%c' % (18,graph_index,style,start,end,length,row))

	def scroll_on(self):		# sets scroll (ie, if a line feed is done at the bottom row,
		pass

	def scroll_off(self):		# sets the scroll off (see scroll_on description)
		pass

	def set_marq(self, str):				# set the marquee (auto-scrolling line) to a certain string)
		for i in range(len(str)):
			self.out('%c%c' % (21,i))
			self.out(str[i])

	def unset_marq(self):					# clear the marquee
		for i in range(21):
			self.out('%c' % 21)
			self.out('')
		
	def marq_on(self, line, step, speed):	# line is the line on which it will be displayed.
		# line = [0 to 3]				# step is how many pixels it moves each step
		# step = [1 to 6]				# speed is how often it makes those steps.
		# speed = [5 to 100]
		self.out('%c%c%c%c' % (22,line,step,speed))

	def marq_off(self):						# stops the marquee
		self.marq_on(255,1,5)

	def wrap_on(self):						# set line wrap on
		self.out('%c' % 23)
			
	def wrap_off(self):						# set line wrap off
		pass

	def set_custom(self, char,d0,d1,d2,d3,d4,d5,d6,d7):			# set custom characters.  char is the character (0-7 to set)
		pass

	def show_custom(self, char):		#show the custom character number #char)
		self.out('%c' % (128+char))

	def reboot(self):						# reboot the firmware (rarely needed)
		self.out('%c%c%c%c%c%c%c%c%c%c%c' % (32,32,32,32,32,32,32,32,32,26,26))

	def up(self):							# move cursor up
		self.out('%c%c%c') % (27,91,65)

	def down(self):							# move cursor down
		self.out('%c%c%c') % (27,91,66)

	def right(self):						# move cursor right
		self.out('%c%c%c') % (27,91,67)

	def left(self):							# move cursor left
		self.out('%c%c%c') % (27,91,68)

	def bignum(self, style, col, num):			# display built-in large number. 
		# style = 0 for 3x4, 1 for 4x4
		# column = 0 to 17 for style0, 0 to 16 for style 1
		self.out('%c%c%c%c' % (28,style,col,num+48))

	def line(self, linenum, text):			# display a line of text
		self.lines[linenum] = string.ljust(string.strip(text),self.cols)
		self.need_update = 1		

	def cline(self, linenum, text):			# display a line of centered text
		text = string.center(text,self.cols)
		self.line(linenum, text)

	def blankline(self, linenum):
		string = ""
		for i in range(self.cols):
			string = string + " "
		self.lines[linenum] = string
		self.need_update = 1
