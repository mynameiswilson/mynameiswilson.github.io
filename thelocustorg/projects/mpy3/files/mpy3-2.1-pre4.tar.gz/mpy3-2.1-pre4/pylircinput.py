# pylirc.py
#
# lirc input handler for mpy3
# Written by Paul Jennings (pjennings-mpy3@pjennings.net)
# Heavily based upon pyjoyinput.py by Ben Wilson (ben@thelocust.org)

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
# or have a look at http://www.fsf.org/licenses/gpl.txt



import os, string, socket

class Input:

	debug_on = 1

	device = ""
	running = 0
	devicedesc = ""
	driverversion = ""
	buttonmap = ""
	axmap = ""
	configstring = ""

	character = ""
	
	buttontime = []
	axistime = []
	configs = {}

	def __init__(self, device="/dev/lircd"):

		self.debug("LIRCInput Initalizing")

		self.device = device
		self.running = 1

		self.configs = self.parseconfig()
		print self.configs

		self.debug("Opening LIRC device: " + str(device))
		self.lircsock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
		self.lircsock.connect(self.device)
	
	def parseconfig(self):
		#parse that config file!

		#silly rabbit -- need to make this dynamic, so that when mpy3.py is called with
		# myconf.conf, it will respect that one.
		config_file = "pylircinput.conf"
		ConfigError = "Config File " + config_file + " NOT FOUND!"

		# import python's native Configuration Parser
		import ConfigParser
		configs = {}

		# try to open the config file
		if(os.path.isfile(config_file)):	
			myparser = ConfigParser.ConfigParser()			# start an instance of the config parser
			myparser.read(config_file)					# read in the config file named above in config_file
		
			temp = {}	

			for section in myparser.sections():							# for each section
			
				for option in myparser.options(section):				# and each option for each section
					temp[option] = myparser.get(section,option)		
				
				configs[section] = temp				# assign a dictionary entry in the dictionary 'configs'
				temp = {}

		# otherwise raise an Error
		else:
			raise ConfigError			# no Config file?  bombs away!

		# return the "configs" list, which is a big ol' multidimensional config array
		return configs


	def debug(self,text):
		if (self.debug_on == 1):
			print "pyLIRCInput: " + str(text)


	def shutdown(self):
		self.running = 0

	
	def handle_input(self):
		self.debug("starting input")

		configstring = ""
		while self.running == 1:
			data = self.lircsock.recv(1024)
			data = data.splitlines()[0] #Remove trailing newline
			data = data.split(" ")
			try:
				if int(data[1]) == 0:
					self.debug("Received "+data[2]+" from "+data[3])
					try:
						self.character = self.configs['pylircinput'][data[2].lower()]
					except KeyError:
						self.debug(data[2]+" is not defined in the config file -- ignoring.")
			except ValueError:
				self.debug("User appears to be holding down "+data[2])
			if not data: break
