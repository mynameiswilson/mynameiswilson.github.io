#!/bin/sh
#
# sample shell script for running mpy3 and redirecting output to a certain tty.  
# handy for remote control users.
# remember to disable the getty on that tty, though!

#/usr/local/sbin/lircd /usr/share/cajun/lib/lircd.conf
#cd /home/ben/mpy3/1.0
#./Cajun
#/usr/local/bin/irpty lircrc 

./mpy3.py > /dev/tty8
