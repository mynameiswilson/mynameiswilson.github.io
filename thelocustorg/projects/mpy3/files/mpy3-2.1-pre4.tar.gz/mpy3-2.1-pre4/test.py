#!/usr/bin/python
import pyjoy
x = pyjoy.JoyInput()
x.running = 1
x.handle_input()
