# pyjoy.py
#
# joystick input handler for mpy3
#
#  from /usr/src/linux/Documentation/input/joystick-api.txt
#
#	struct js_event {
#		__u32 time;     /* event timestamp in milliseconds */
#		__s16 value;    /* value */
#		__u8 type;      /* event type */
#		__u8 number;    /* axis/button number */
#	};
#
"""
2.1 js_event.type
~~~~~~~~~~~~~~~~~

The possible values of ``type'' are

	#define JS_EVENT_BUTTON         0x01    /* button pressed/released */
	#define JS_EVENT_AXIS           0x02    /* joystick moved */
	#define JS_EVENT_INIT           0x80    /* initial state of device */#


the output from a read (unpacked):

(707719510L, 1, 1, 1)
(707719600L, 0, 1, 1)


for my Interact ProPad
left-right: axis 0
up-down: axis 1
left shoulder: axis 2 (-32767 is "button press")
right shoulder: axis 3(-32767 is "button press")
button 1: button 0
button 2: button 1
button 3: button 2
button 4: button 3
button 5: axis 2 (-32767 is "button press")
button 6: axis 3 (-32767 is "button press")


"""
import select, os, struct, fcntl, JOYSTICK, string
from time import sleep



class Input:

	debug_on = 1

	device = ""
	running = 0
	devicedesc = ""
	numaxes = ""
	numbuttons = ""
	driverversion = ""
	buttonmap = ""
	axmap = ""
	configstring = ""

	character = ""
	
	buttontime = []
	axistime = []
	configs = {}

	def __init__(self, device="/dev/input/js0"):

		self.debug("JoyInput Initalizing")

		self.device = device
		self.running = 1

		self.configs = self.parseconfig()
		print self.configs

		self.debug("Opening Joystick device: " + str(device))
		self.joydev = os.open(self.device, os.O_NONBLOCK)
		
		
		self.devicedesc = string.replace( fcntl.ioctl(self.joydev,JOYSTICK.JSIOCGNAME(255),struct.pack('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')), '\x00','')
		self.numaxes = ord( string.replace( fcntl.ioctl(self.joydev,JOYSTICK.JSIOCGAXES, struct.pack('B',0)), '\x00','' ) )
		self.numbuttons = ord( string.replace( fcntl.ioctl(self.joydev,JOYSTICK.JSIOCGBUTTONS, struct.pack('xxxxxxxxxxxxxx')), '\x00','' )  )

		self.debug("Device Desc      : " + str(self.devicedesc))
		self.debug("Number of Axes   : " + str(self.numaxes))
		self.debug("Number of Buttons: " + str(self.numbuttons) )
	
	def parseconfig(self):
                #parse that config file!

                #silly rabbit -- need to make this dynamic, so that when mpy3.py is called with
	        # myconf.conf, it will respect that one.
		config_file = "pyjoyinput.conf"
		ConfigError = "Config File " + config_file + " NOT FOUND!"

                # import python's native Configuration Parser
		import ConfigParser
		configs = {}

	        # try to open the config file
		if(os.path.isfile(config_file)):	
			myparser = ConfigParser.ConfigParser()			# start an instance of the config parser
			myparser.read(config_file)					# read in the config file named above in config_file
		
			temp = {}	

			for section in myparser.sections():							# for each section
			
				for option in myparser.options(section):				# and each option for each section
					temp[option] = myparser.get(section,option)		
				
				configs[section] = temp				# assign a dictionary entry in the dictionary 'configs'
				temp = {}

                # otherwise raise an Error
		else:
			raise ConfigError			# no Config file?  bombs away!

                # return the "configs" list, which is a big ol' multidimensional config array
		return configs


	def debug(self,text):
		if (self.debug_on == 1):
			print "pyJoyInput: " + str(text)


	def shutdown(self):
		self.running = 0

	
	def handle_input(self):
		self.debug("starting input")

		configstring = ""
		while self.running == 1:
			r, w, e = select.select([self.joydev], [], [])
			
			if r:
				x = os.read(self.joydev,8)
				event = struct.unpack('IhBB',x)

				type, value, number, action, time, elapsedtime = "","","","","",0

				time = event[0]
				value = event[1]
				typenum = event[2]
				number = event[3]


				if typenum == 1:
					
					type = "button"
					if value == 0:
						action = "up"
					elif value == 1:
						action = "down"

					if (self.buttontime[number] > 0):
						elapsedtime = time - self.buttontime[number]
						self.buttontime[number] = 0
					else:
						self.buttontime[number] = time

					configstring = str(type)+str(number)+"-"+str(action)
					self.debug(configstring)
					self.debug(self.configs['pyjoyinput'][configstring])
					self.character = self.configs['pyjoyinput'][configstring]



						
				elif typenum == 2:

					type = "axis"
					if value > 0:
						action = "up"
					elif value < 0:
						action = "down"
					elif value == 0:
						action = "center"

					if (self.axistime[number] > 0):
						elapsedtime = time - self.axistime[number]
						self.axistime[number] = 0
					else:
						self.axistime[number] = time

					configstring = str(type)+str(number)+"-"+str(action)
					self.debug(configstring)
					self.debug(self.configs['pyjoyinput'][configstring])
					self.character = self.configs['pyjoyinput'][configstring]
					

				elif typenum == 129:
					type = "initialize button"
					self.buttontime.append(0)

				elif typenum == 130:
					type = "initialize axis"
					self.axistime.append(0)


				
				debugstr = "EVENT: " + type + " " + str(number) + " " + action + " (" + str(value) + ") "
				
				elapsedsecs = float(elapsedtime)/1000
				if (elapsedsecs > 0):
					debugstr = debugstr + str(elapsedsecs) + " seconds"
				
				self.debug(debugstr)


