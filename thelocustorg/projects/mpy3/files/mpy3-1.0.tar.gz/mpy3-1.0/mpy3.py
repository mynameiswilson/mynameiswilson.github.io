#!/usr/bin/env python
#
# Name: MPy3 
# Desc: MP3 Management System written in Python  
# Date: 1/01/2001
# Vers: 0.1.0
#
# Copyright (C) 2001 Ben Wilson
#
#This program is free software; you can redistribute it and/or
#modify it under the terms of the GNU General Public License
#as published by the Free Software Foundation; either version 2
#of the License, or (at your option) any later version.
#
#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#
#You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
#
# http://mpy3.thelocust.org
# http://mpy3.sourceforge.net
#
# Contact: ben@thelocust.org / thelocust@users.sourceforge.net
#

import sys, os, select
import ConfigParser, tty, termios, TERMIOS, time

import pyCFontz		# python library to control CrystalFontz LCD
import pymix		# python library for controlling aumix
import pyrx		# python library
import listmp3		# python library for MP3 list control

import FCNTL, fcntl
from fcntl import fcntl
from FCNTL import F_SETFL, F_SETFD, O_NONBLOCK


#MPy3 Class###############################################################################
class mpy3:

	init_state = "welcome"
	config_file = "mpy3.conf"
	configs = {}

	ConfigError = "Config File " + config_file + " NOT FOUND!"

	running = 0

        def __init__(self):
		self.settty(1)
		self.state = self.init_state
		self.running = 1
		self.moreinfo = 0
		self.parseconfig()

		if(int(self.configs['general']['debug'])):
				self.debug = 1
		else:
				self.debug = 0

		if(int(self.configs['lcd']['use_lcd'])):
			self.setup_lcd()

		self.setup_player()
		self.setup_mixer()
		self.setup_list()
		self.setup_special_chars()

		
	
	########################################################################
	# settty - set the stdin of whereever you are running this to raw input
	# so that input doesn't have to have a CRLF after it to be picked up by
	# read()
	#
	# raw - either 1 (for raw) or 0 to set it back
	#
	def settty(self,raw):
		tt = sys.stdin.fileno()			# get the file number of the STDIN

		if raw:									# if the passed arg "raw" is set to one, or true
			self.mode = termios.tcgetattr(tt)	# set an object parameter to the original state of the STDIN
			tty.setraw(tt,TERMIOS.TCSANOW)		# set the STDIN to raw (necessary for input handling, etc
		else:
			if self.mode:											# if "raw" is zero, or false
				termios.tcsetattr(tt, TERMIOS.TCSANOW,self.mode)	# then set the STDIN back to the original state
																	# otherwise, you wouldn't see your text.

	#######################################################################
	# parseconfig - parse the configuration file (whose filename is stated as an object parameter above)
	# and put all of the options into a dictionary called configs (also stated above)
	#

	def parseconfig(self):
		if(os.path.isfile(self.config_file)):	
			myparser = ConfigParser.ConfigParser()			# start an instance of the config parser
			myparser.read(self.config_file)					# read in the config file named above in config_file
			
			temp = {}	
	
			for section in myparser.sections():							# for each section
				
				for option in myparser.options(section):				# and each option for each section
					
					temp[option] = myparser.get(section,option)		
					
				self.configs[section] = temp				# assign a dictionary entry in the dictionary 'configs'
				temp = {}


		else:
			raise self.ConfigError				# no Config file?  bombs away!

	#######################################################################
	# setup_lcd - using the lcd library, open the LCD on the port from the config file, clear it, 
	# hide the cursor, and set the contrast to the init_contrast level stated in the config

	def setup_lcd(self):
		self.mylcd = pyCFontz.open_lcd(self.configs['lcd']['port'])	# create instance of the LCD on port from config 
		self.mylcd.cls()												# clear the screen of the LCD
		self.mylcd.hide_cursor()										# hide the cursor
		self.mylcd.wrap_off()
		self.mylcd.scroll_off()
		self.mylcd.set_contrast(int(self.configs['lcd']['init_contrast']))
																	# set the contrast to the init_contrast from the config
		self.mylcd.set_backlight(int(self.configs['lcd']['init_backlight']))	
																	# set backlight intensity to the init_backlight from cfg

	def setup_player(self):
		self.mylcd.out("Init rXaudio")
		self.myplayer = pyrx.player()  		# create instance of the rxaudio MP3 player
		self.mylcd.out(" [Ok]")
		self.mylcd.crlf()

	def setup_mixer(self):
		self.mylcd.out("Init Mixer")
		self.mymixer = pymix.mixer(	self.configs['mixer']['inittreble'], \
									self.configs['mixer']['initbass'],\
									self.configs['mixer']['initvolume'],\
									self.configs['mixer']['initpcm'],\
									self.configs['mixer']['initcd'],\
									self.configs['mixer']['increment'])
		self.mylcd.out(" [Ok]")
		self.mylcd.crlf()

	def setup_list(self):
		self.mylcd.out("Making List")
		self.mylist = listmp3.mp3list()			# create instance of the listMP3 module
		self.mylist.findfiles(self.configs['general']['mp3dir'])	
												# populate list.mp3list with files from that directory (recursively)
		self.mylcd.out(" [Ok]")
		self.mylcd.crlf()

	def setup_special_chars(self):
		self.mylcd.set_custom(0,63,33,45,33,45,45,33,63)
			# set custom char 0 to the "info" box for signifying extra id3 info.

	########################################################################
	# getkey - HEY!  It's gets a key from STDIN
	# it will return that key, btw.
	# 
	def getkey(self):
		
		r,w,e = select.select([sys.stdin],[],[],0)
		if r:
      			ch = sys.stdin.read(1)
			termios.tcflush(sys.stdin.fileno(), TERMIOS.TCIFLUSH)	
			if self.debug: print "got key: " + ch
        		return ch
		else:
			return ""
	
	def handle_events(self):
		myplayer = self.myplayer
		mylist = self.mylist
		mylcd = self.mylcd
		mymixer = self.mymixer
		configs = self.configs

		if self.state == "welcome":
			self.state_welcome("enter","")
		elif self.state == "main":
			self.state_main("enter","")

		while (self.running == 1):
			x = self.getkey()	

			### BEGIN GLOBALS ###
			if x == configs['global']['quit']:
				self.state_shutdown("enter","")
				self.running = 0

			elif x == configs['global']['main']:
				self.state_main("enter","")

			elif (x == configs['play']['play']) and (self.state != "play"):
				self.play()
			elif (x == configs['play']['next']) and (self.state != "play"):
				self.nextsong()
			elif (x == configs['play']['prev']) and (self.state != "play"):
				self.prevsong()
			elif (x == configs['play']['pause']) and (self.state != "play"):
				myplayer.pause()
			elif (x == configs['play']['stop']) and (self.state != "play"):
				myplayer.stop()
			elif (x == configs['play']['random']) and (self.state != "play"):
				mylist.randomize()

			elif (x == configs['audio']['volup']) and (self.state != "audio"):
				mymixer.volup()
			elif (x == configs['audio']['voldown']) and (self.state != "audio"):
				mymixer.voldown()

			### BEGIN STATES ###

			elif self.state == "main":
				self.state_main("key",x)
			elif self.state == "play":
				self.state_play("key",x)
			elif self.state == "config":
				self.state_config("key",x)
			elif self.state == "listview":
				self.state_listview("key",x)
			elif self.state == "audio":
				self.state_audio("key",x)
			elif self.state == "display":
				self.state_display("key",x)

			if myplayer.state == "eof":
				if self.state == "play": mylcd.cls()
				self.nextsong()				
			
			if myplayer.state == "play":
				myplayer.handle_audio()

	def play(self):
		myplayer = self.myplayer
		mylist = self.mylist

		if(self.debug): print "playing:" + mylist.current()
		myplayer.play(mylist.playlist[mylist.index])
		
	def nextsong(self):
		mylist = self.mylist
		myplayer = self.myplayer

		mylist.next()
		if(self.debug): print "playing:" + mylist.playlist[mylist.index]
		myplayer.play(mylist.playlist[mylist.index])
			
	def prevsong(self):
		mylist = self.mylist
		myplayer = self.myplayer

		mylist.prev()
		if(self.debug): print "playing:" + mylist.playlist[mylist.index]
		myplayer.play(mylist.playlist[mylist.index])


	def state_welcome(self,interrupt,key):
		myplayer = self.myplayer
		mylist = self.mylist
		mylcd = self.mylcd
		configs = self.configs		

		mylcd.cls()
		mylcd.line(0,"Welcome to....")
		mylcd.line(1,"MPy3")
		mylcd.line(2," by ")
		mylcd.line(3,"Ben Wilson")
		time.sleep(2.0)

		if (int(configs['player_options']['shuffle_on_start'])): mylist.randomize()
		if (int(configs['player_options']['play_on_start'])): self.play()

		self.state_main("enter","")

	def state_main(self,interrupt,key):
			if (interrupt == "enter"):
				self.state = "main"
				self.display_main()
			elif (interrupt == "key"):
				if (key == self.configs['main']['state_play']):
					self.state_play("enter","")
				elif (key == self.configs['main']['state_config']):
					self.state_config("enter","")
				elif (key == self.configs['main']['state_audio']):
					self.state_audio("enter","")
				elif (key == self.configs['main']['state_display']):
					self.state_display("enter","")
	
	def display_main(self):
		configs = self.configs
		myplayer = self.myplayer
		mylist = self.mylist
		mylcd = self.mylcd

		mylcd.cls()
		mylcd.cline(0,"main menu")
		mylcd.cline(1,str(configs['main']['state_play']) + ". play  " + str(configs['main']['state_config']) + ". config")
		mylcd.cline(2,str(configs['main']['state_audio'])+ ". audio " + str(configs['main']['state_display']) + ". display")
		mylcd.cline(3,str(configs['global']['quit']) + " to quit")

	def state_shutdown(self,interrupt,key):
		myplayer = self.myplayer
		mylist = self.mylist
		mylcd = self.mylcd

		self.state = "shutdown"
		self.playing = 0

		myplayer.stop()
		
		self.settty(0)

		mylcd.cls()
		mylcd.cline(0,"thanks for using")
		mylcd.cline(1,"MPy3")
		mylcd.cline(2," by ")
		mylcd.cline(3,"Ben Wilson")
		time.sleep(3.0)
		mylcd.cls()

	def state_play(self,interrupt,key):
			myplayer = self.myplayer
			mylist = self.mylist
			mylcd = self.mylcd
			mymixer = self.mymixer

			#self.display_play()

			if (interrupt == "enter"):
				self.state = "play"
				mylcd.cls()
				self.display_play()

			elif (interrupt == "key"):
								
				if(key == self.configs['play']['play']):
					self.play()
										
				elif(key == self.configs['play']['pause']):
					myplayer.pause()

				elif(key == self.configs['play']['stop']):
					myplayer.stop()
					
				elif(key == self.configs['play']['prev']):
					mylcd.cls()
					
					if myplayer.state == "play":
						self.prevsong()
					else:
						mylist.prev()					

				elif(key == self.configs['play']['next']):
					mylcd.cls()
									
					if myplayer.state == "play":
						self.nextsong()
					else:
						mylist.next()

				elif(key == self.configs['play']['random']):
					mylist.randomize()
				
		
				elif(key == self.configs['play']['moreinfo']):
					if (self.moreinfo == 0):
							self.moreinfo = 1
							mylcd.cls()
					else:
							self.moreinfo = 0 
							mylcd.cls()
		
			self.display_play()

			
	def display_play(self):
		myplayer = self.myplayer
		mylist = self.mylist
		mylcd = self.mylcd		
		
		line0 = mylist.songname
		line1 = mylist.artist
		
		if (self.moreinfo == 1):
			line2 = mylist.album
			line3 = mylist.comment

		else:
			line2 = str(mylist.index+1) + "/" + str(mylist.size) + " " 


			if (int(self.configs['player_options']['show_time_remaining'])==1):
					line2 = line2 + "-" + str(myplayer.minremain)+":"+str(myplayer.secremain)
			else:
					line2 = line2 + str(myplayer.min)+":"+str(myplayer.sec)
		

			line3 = myplayer.bitrate + "kbps " + myplayer.frequency + "kHz"

			if (len(mylist.album)>0 or len(mylist.comment)>0):
				mylcd.cursor(18,3)
				mylcd.show_custom(0)

		mylcd.cline(0,line0)
		mylcd.cline(1,line1)
		mylcd.cline(2,line2)
		mylcd.cline(3,line3)

	def state_listview(self,interrupt,key):
		myplayer = self.myplayer
		mylist = self.mylist
		mylcd = self.mylcd
		mymixer = self.mymixer
		
		if (interrupt == "enter"):
				self.state = "listview"
				mylcd.cls()
				

		elif (interrupt == "key"):
			if(key==">"):
				mylist.next()
			elif(key=="<"):
				mylist.prev()
			elif(key=="p"):
				self.state_play("enter","")

		self.display_listview()

	def display_listview(self):
		mylcd = self.mylcd
		mylist = self.mylist

		#mylcd.cls()
		mylcd.line(0,"Playlist View")
		mylcd.line(1,mylist.artist)		
		mylcd.line(2,mylist.songname)

	def state_audio(self,interrupt,key):
		mymixer = self.mymixer
		mylcd = self.mylcd
		configs = self.configs

		self.state == "audio"

		if (interrupt == "enter"):
				self.state = "audio"
				self.display_audio()
		
		elif (interrupt == "key"):
		
			if(configs[self.state].has_key('voldown') and key == str(configs['audio']['voldown'])):
				mymixer.voldown()

			elif(configs[self.state].has_key('voldefault') and key == str(configs['audio']['voldefault'])):
				mymixer.setvolume(configs['mixer']['initvolume'])

			elif(configs[self.state].has_key('volup') and key == str(configs['audio']['volup'])):
				mymixer.volup()

			elif(configs[self.state].has_key('trebledown') and key== configs['audio']['trebledown']):
				mymixer.trebledown()

			elif(configs[self.state].has_key('trebledefault') and key == str(configs['audio']['trebledefault'])):
				mymixer.settreble(configs['mixer']['inittreble'])

			elif(configs[self.state].has_key('trebleup') and key == configs['audio']['trebleup']):
				mymixer.trebleup()

			elif(configs[self.state].has_key('bassdown') and key == configs['audio']['bassdown']):
				mymixer.bassdown()

			elif(configs[self.state].has_key('bassdefault') and key == str(configs['audio']['bassdefault'])):
				mymixer.setbass(configs['mixer']['initbass'])

			elif(configs[self.state].has_key('bassup') and key == configs['audio']['bassup']):
				mymixer.bassup()

			if(key!=""):
				self.display_audio()
		
	

	def display_audio(self):
		mylcd = self.mylcd
		mymixer = self.mymixer

		mylcd.cls()
		mylcd.cline(0,"audio settings")

		mylcd.hbar(1,60,3,19,mymixer.volume,1)
		mylcd.hbar(2,60,3,19,mymixer.treble,2)
		mylcd.hbar(3,60,3,19,mymixer.bass,3)

		mylcd.cursor(0,1)
		mylcd.out("vol")
		mylcd.cursor(10,1)
		mylcd.out(str(mymixer.volume))

		mylcd.cursor(0,2)
		mylcd.out("tre")
		mylcd.cursor(10,2)
		mylcd.out(str(mymixer.treble))

		mylcd.cursor(0,3)
		mylcd.out("bas")
		mylcd.cursor(10,3)
		mylcd.out(str(mymixer.bass))

		
	def state_display(self,interrupt,key):
		mylcd = self.mylcd
		configs = self.configs

		self.state == "display"

		if (interrupt == "enter"):
				self.state = "display"
				self.display_display()
		
		elif (interrupt == "key"):
		
			if(configs[self.state].has_key('contrastdown') and key==configs['display']['contrastdown']):
				mylcd.contrastdown()

			elif(configs[self.state].has_key('contrastup') and key==configs['display']['contrastup']):
				mylcd.contrastup()

			elif(configs[self.state].has_key('backlightdown') and key==configs['display']['backlightdown']):
				mylcd.backlightdown()

			elif(configs[self.state].has_key('backlightup') and key==configs['display']['backlightup']):
				mylcd.backlightup()

			elif(configs[self.state].has_key('backlight_on') and key==configs['display']['backlight_on']):
				mylcd.backlight_on()

			elif(configs[self.state].has_key('backlight_off') and key==configs['display']['backlight_off']):
				mylcd.backlight_off()

			if(key!=""):
				self.display_display()
		
	

	def display_display(self):
		mylcd = self.mylcd

		mylcd.cls()
		mylcd.cline(0,"disp settings")

		mylcd.hbar(1,60,3,19,mylcd.contrast,1)
		mylcd.hbar(2,60,3,19,mylcd.backlight,2)

		mylcd.cursor(0,1)
		mylcd.out("con")
		mylcd.cursor(10,1)
		mylcd.out(str(mylcd.contrast))

		mylcd.cursor(0,2)
		mylcd.out("bck")
		mylcd.cursor(10,2)
		mylcd.out(str(mylcd.backlight))

		if(mylcd.backlight > 0):
			mylcd.cline(3,"backlight is on")
		else:
			mylcd.cline(3,"backlight is off")


	def state_config(self, interrupt, key):
		mylcd = self.mylcd
		mylist = self.mylist
		configs = self.configs

		self.state = "config"

		if (interrupt == "enter"):
			self.display_config()
		
		elif (interrupt == "key"):
			if(key == self.configs['config']['random']):
					mylist.randomize()
					self.display_config()
		

	def display_config(self):
		mylcd = self.mylcd
		mylist = self.mylist		
		
		mylcd.cls()

		if (int(mylist.israndom)): 
			randstatus = "on"
		else: 
			randstatus = "off"

		line0 = "config"
		line1 = "random play: " + randstatus


		mylcd.cline(0,line0)
		mylcd.line(1,line1)
		


#END CLASS###############################################################################

mympy3 = mpy3()

mympy3.handle_events()

	

