#!/usr/bin/env python
#
# Name: listmp3
# Desc: library for managing playlists
# Date: 1/04/2001
# Vers: 0.1.0
#
# Copyright (C) 2001 Ben Wilson
#  
#
# This library is free software; you #can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#
#	http://mpy3.sourceforge.net
#	Contact: ben@thelocust.org / thelocust@users.sourceforge.net
#
#
# init the thing like this:
# 	foo = listmp3.mp3list()
#	foo.findfiles("/path/to/mp3s")
#
#	this will find all mp3 files under that directory.  be forewarned,
#	a lot of mp3s will take a while to list, though on my Pentium-100,	
#	2500 MP3s takes about 10 seconds.
#
#	foo.list will be the master list of songs
#	foo.playlist is the list that is used.  if not randomized, then this is a just a copy
#			of foo.list.  If randomized, this is a randomized copy foo.list
#
# methods:
#
#	clear() - clear the list
#	next() - bump up the index one. also, if you attempt to go past the
#			end of the list, it returns to the first spot.
#	prev() - previous index in list. also, if you attempt to go to the song
#		before the beginning of the list, it goes to the end.
#	
#	randomize() - randomizes the playlist.  
#	get_current_tag() - you shouldn't need this, as it is all handled internally,
#			though it just gets the current taginfo from the current file
#
#	current() - returns the filename of the MP3 that is the current index.
#
#
# properties:
#
#	songname - uh.. the songname of the current file.  
#	artist 	- uh.. the artist of the current file.
#	album 	- uh.. the artist of the current file.
#	comment 	- uh.. the artist of the current file.



import os
import string
import random
import mp3infor

class mp3list:
	list = []
	index = 0 

	def __init__(self):
		self.clear() 		# initialize the playlist to nil

	def clear(self):
		self.list = []		# clear the playlist
		self.playlist = []
		self.index = 0
		self.size = 0
		self.israndom = 0

	def findfiles(self, directory):
		filenames = os.listdir(directory)

		for filename in filenames:		# recursive search for MP3s

			fullpath = directory + "/" + filename	# assemble full path name from directory and 
								# filename separated by "/"

			if os.path.isfile(fullpath):
				if string. upper(fullpath[-3:]) == "MP3":	# compare the last three letter in the 
															# fullpath string to MP3, and if it is MP3
					self.list.append(fullpath)   			# then append it to the playlist

			if os.path.isdir(fullpath):		# if the pathname is a directory
				self.findfiles(fullpath)	# then call another instance of yourself
											# and descend deeper!
		self.size = len(self.list)
		self.playlist = self.list
		self.get_current_tag()

	def current(self):
		return self.list[self.index]

	def next(self):
		if (self.israndom == 1):
			random.seed()
			self.index = random.randint(0,self.size)
		else:

			if (self.index==self.size-1):		
				self.index=0
			else:
				self.index = self.index + 1

		self.get_current_tag()

	def prev(self):
		if (self.israndom == 1):
			random.seed()
			self.index = random.randint(0,self.size)
		else:
			if (self.index==0):		
				self.index=self.size-1
			else:
				self.index = self.index - 1

		self.get_current_tag()

	def randomize(self):
		if (self.israndom == 1):				
			self.israndom = 0			
		else:						
			self.israndom = 1		

		

	def get_current_tag(self):
		
		self.songname, self.artist, self.album, self.comment = "","","",""
		mymp3 = mp3infor.open_mp3(self.list[self.index])	
		try:
			mymp3.read_tag()
			self.songname = mymp3.songname
			self.artist = mymp3.artist
			self.album = mymp3.album
			self.comment = mymp3.comment
			
		except mp3infor.NoTagError:
			self.songname = ""
			self.artist = ""
			self.album = ""
			self.comment = ""

	
	
