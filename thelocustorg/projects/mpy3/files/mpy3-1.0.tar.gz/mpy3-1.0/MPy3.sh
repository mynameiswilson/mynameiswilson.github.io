#!/bin/sh

#/usr/local/sbin/lircd /usr/share/cajun/lib/lircd.conf
#cd /home/ben/mpy3/1.0
#./Cajun
/usr/local/bin/irpty lircrc ./mpy3.py < /dev/tty1
