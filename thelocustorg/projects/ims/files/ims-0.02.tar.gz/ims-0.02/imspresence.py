# IMS "Presence" class
# version: 0.1
# date   : 2002.08.21
# desc   : a "user" class for IMS, to handle user preferences, conversations, etc.

import time
class IMSPresence:


      def __init__(self,service,screenname):
          self.debug_on = 1
	  
	  self.messageLog = []

	  # mode handling variables
	  self.modeEnabled = 0
	  self.modeCurrent = ""

	  self.service = service
	  self.screenname = screenname
	  self.initTime = time.time()
	  self.debug("initializing presence " + self.service + ", " + self.screenname + " @ " + str(self.initTime))

      def debug(self,text):
           if (self.debug_on == 1):
                print("IMSPresence DEBUG: " + str(text))

      def logMessage(self,message):
	  self.debug("appending message to log - " + message)
	  self.messageLog.append(message)
