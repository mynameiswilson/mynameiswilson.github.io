# moduptime.py for instant manservant
# 04.15.2002
# copyright ben wilson, 2002-INFINITY

# example module for instant manservant

import time, os
from string import lower,strip

# each module needs a class called "IMSModule"
class IMSModule:

      def __init__(self):

	  #each module also should have a name, desc, version, date
	  #author, and URL
	  self.name = "uptime"
	  self.desc = "simple module to return the current uptime of the machine that IMS is running on!"
	  self.version = "0.01"
	  self.date    = "04.15.2002"
	  self.author  = "ben wilson"
	  self.url     = "http://thelocust.org/projects/ims"
	  

	  self.running = 0
	  self.debug_on = 1

	  # each module also has a "trigger word", which is 'registered' with
	  # the IMS core.  so, when the core receives a message as such: 'uptime help',
	  # it knows who to give that command to
	  self.trigger = "uptime"

	  self.actions = ("help","about")


	  # each module also has it's own incoming/outgoing message queues.
	  self.incomingMessageQueue = []	  
	  self.outgoingMessageQueue = []
	 
	  self.debug("initialization complete!")
	  self.running = 1	  

      def debug(self,text):
	  if self.debug_on == 1:
	  	  print self.name + ':' + str(text)	  

      def mainLoop(self):
	  self.debug("mainLoop: starting!")
	  while self.running == 1:
		time.sleep(0.5)
		if len(self.incomingMessageQueue) > 0:
		   self.handleMessage(self.incomingMessageQueue.pop())


      def handleMessage(self,data): 
	  self.debug("handling message - " + data)
	  dataComponents = data.split(":")

	  service = dataComponents[0]
	  screenName = dataComponents[1]
	  message = ":".join(dataComponents[2:])
	  
	  messageArray = message.split(" ")	  

	  if lower(messageArray[0]) == self.trigger :

	     if len(messageArray) > 1:
		if lower(messageArray[1]) == 'help' :
		   self.debug("got request for help")
		   self.sendMessage(service,screenName,self.showHelp(message))  
		elif lower(messageArray[1]) == "about" :
		   self.debug("got request for about")
		   self.sendMessage(service,screenName,self.showAbout())  
	     else:
		self.debug("got request for uptime")
		self.sendMessage(service,screenName,self.showUptime())

	  else:
	     self.debug("this message - '" + data + "' - isn't for me") 

      def sendMessage(self,service,screenName,text):
	  self.outgoingMessageQueue.append(service + ":" + screenName + ":" + text)


      def showHelp(self,message):
	  helpText = "uptime has the following commands: "
	  for i in self.actions:
	      helpText = helpText + " " + i
	  return helpText

      def showAbout(self):
	  aboutText = self.name + " v" + self.version + " - " + self.date + " by " + self.author + " url: " + self.url  
	  return aboutText

      def showUptime(self):
	  uptimePipe = os.popen('uptime')
	  uptimeText = uptimePipe.readline()
	  uptimePipe.close()
	  self.debug('uptimeText ==>' + uptimeText)
	  return uptimeText

