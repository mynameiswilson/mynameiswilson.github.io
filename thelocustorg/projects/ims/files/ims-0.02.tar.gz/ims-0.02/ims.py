#!/usr/bin/python
# paim v0.1
#
# requires Py-TOC
# http://jamwt.com/Py-TOC/

import sys, os.path, string, time, re
from threading import Thread
from tocbot import TocBot
from imspresence import IMSPresence

class InstantManservant:

      errors = {}
      modules = {}
      presences = {}
      errors['NoConfigFile'] = "config file ims.conf not found!"
      errors['NoConfigScreenname'] = "you need a screenname in the config file!"
      errors['NoConfigPasswd'] = "you need a password in the config file!"

      def __init__(self):
	  self.debug_on = 1
	  self.configs = self.readConfig()
	  self.debug(self.configs)
	  
	  self.name = "instantManservant"
	  self.desc = "instant message bot framework!" 
	  self.version = "0.3"
	  self.date    = "2002.08.21"
	  self.author  = "ben wilson"
	  self.url     = "http://thelocust.org/projects/ims"

	  self.debug("init: checking configs")
	  self.checkConfig()

	  self.debug("init: initializing bots")
	  self.initBot()

	  self.debug("init: registering modules")
	  self.registerModules()

	  self.debug("init: entering mainLoop")
	  try:
	  	  self.mainLoop()
	  except KeyboardInterrupt:
		 self.shutdown()

      def shutdown(self):
	  self.debug("shutdown: shutting down bot thread!")
	  self.myBot.shutdown()
	  self.myBotThread.join()

	  for module in self.modules:
	      self.debug("shutdown: stopping module " + module)
	      self.modules[module]['object'].running = 0
	      self.debug("shutdown: stopping thread " + module)
	      self.modules[module]['thread'].join()
	  
	  self.debug("shutdown: goodbye! thanks for using " + self.name + " " + self.version)
	  sys.exit()


      def debug(self,text):
	   if (self.debug_on == 1):
		print("IMS DEBUG: " + str(text))
	         
      def throwError(self,text):
	  if __name__ != "__main__":
	     raise self.errors[text]
	  try:	  
		  print "IMS ERROR: " + self.errors[text]
		  self.debug(text + " - " + self.errors[text])
          except KeyError:
		 print "IMS ERROR: " + text

      #parse the config file.  currently, we are only looking for ims.conf
      def readConfig(self):
          #parse that config file!

          config_file = "ims.conf"
          ConfigError = "Config File " + config_file + " NOT FOUND!"

          # import python's native Configuration Parser
          import ConfigParser
          configs = {}

          # try to open the config file
          if(os.path.isfile(config_file)):
		myparser = ConfigParser.ConfigParser()  # start an instance of the config parser
                myparser.read(config_file)              # read in the config file named above in config_file

                temp = {}

		self.debug("readConfig: starting parse")
                for section in myparser.sections():     # for each section

		    self.debug("readConfig: parsing " + section)

		    for option in myparser.options(section):    # and each option for each section
			self.debug("readConfig: found " + option + " in " + section)
			temp[option] = myparser.get(section,option)
			
			self.debug("readConfig: " + option + "=" + temp[option])			

                    configs[section] = temp      # assign a dictionary entry in the dictionary 'configs'
                    temp = {}

          # otherwise raise an Error
          else:
		raise ConfigError                       # no Config file?  bombs away!

          # return the "configs" list, which is a big ol' multidimensional config array
          return configs

      # check the configuration file for the goodness.
      # at the moment, it only checks for a screename and password.
      def checkConfig(self):
	  if ( len ( string.strip( self.configs['ims']['screenname'] ) ) == 0 ):
	     self.throwError("NoConfigScreenname")
	  if ( len ( string.strip( self.configs['ims']['password'] ) ) == 0 ):
	     self.throwError("NoConfigPasswd")


      # start the service bot -- at the moment, it's only TOC (AIM), however, in the future
      # IMS will hopefully support any number of services.
      def initBot(self):
	  self.myBot = TocBot(self.configs['ims']['screenname'],self.configs['ims']['password'])
	  
	  self.debug("iniBot: starting thread!")
          self.myBotThread = Thread(target=self.myBot.go)
	  self.myBotThread.start()

      def registerModules(self):
          for section in self.configs:
	      if section[0:3] == 'mod':
		 self.debug("registerModules: found " + section)
                 try:
			modActive = self.configs[section]['active']
			if modActive == '1' or modActive == 1:
			   self.debug("registerModules: " + section[3:] + " is ACTIVE ")

			   #add this module to the modules listing
			   self.modules[section] = {}

			   #import the module
			   self.debug("registerModules: attempting import of " + section + ".py!")
			   try:
				exec('import ' + section)
				self.debug("registerModules: import of " + section + " successful!")
			   except ImportError:
				self.throwError(section + '.py does not exist! module not loaded')
			   

			   #create an object with the module in it.
			   exec('self.modules[section]["object"] = ' + section + '.IMSModule()')

			   #start a thread with the modules mainLoop in it
			   self.modules[section]["thread"] = Thread(target=self.modules[section]["object"].mainLoop)
			   self.modules[section]["thread"].start()


			else:
			   self.debug("registerModules: " + section + " is INACTIVE")
		 except NameError:
			self.debug("registerModules: " + section + " has no ACTIVE tag, considering inactive")

      def findModuleByTrigger(self, trigger):
	  self.debug("findModuleByTrigger: trying to find Module for '" + trigger + "'")
	  if len(trigger) > 0:
                result = ""
		for key in self.modules:
		    if self.modules[key]['object'].trigger == trigger:
		       result = key
		       return result
		if len(result) == 0:
		       return ""
	  else:
		return ""

      # takes the raw message data and returns the service, screenName and message split by
      # spaces into an array
      def splitMessageData(self,data):
	  dataComponents = data.split(":")
	  service = dataComponents[0]
	  screenName = dataComponents[1]
	  message = ":".join(dataComponents[2:])
	  messageWords = message.split(" ")
		
	  return service,screenName, messageWords

      def mainLoop(self):
	  self.debug("mainLoop: ENTERING!")
	  while 1:
		
		  #check to see if we have a message on the line
		  if self.myBot.queueLength() > 0:

		   #pop that message into a variable
		   data = self.myBot.messageQueue.pop()

		   self.debug("mainLoop: myBot message queue length " + str(self.myBot.queueLength()) ) 
		   self.debug("mainLoop: myBot message - " + data)

		   # split the message into it's components (remember- service:sname:message)
		   dataComponents = data.split(":")
		   service = dataComponents[0]
		   screenName = dataComponents[1]
		   message = ":".join(dataComponents[2:])

		   if self.presences.has_key(string.upper(screenName)):
		      self.presences[string.upper(screenName)].logMessage(message)
		   else:
			self.presences[string.upper(screenName)] = IMSPresence(service,screenName)		   
			self.presences[string.upper(screenName)].logMessage(message)		   

		   # split the message itself into word
		   messageWords = message.split(" ")
		   
		   # attempt to use the first word in the message as the handler
		   self.debug("mainLoop: finding handler for " + messageWords[0])	
		   handlerModule = self.findModuleByTrigger(messageWords[0])

		   # if no handler module found, then IMS will attempt to handle
		   if handlerModule == "":
		      self.debug("mainLoop: didn't find a module, attempting to answer it ourselves")
		      self.handleMessage(data)

		   # if we've found a handler module, send the message to it
		   else:
		      self.debug("mainLoop: found handler " + str(handlerModule) )
		      self.debug("mainLoop: appending message to " + handlerModule + "'s incoming message queue ")
		      self.modules[handlerModule]['object'].incomingMessageQueue.append(data)

		  # send messages for each of the modules
		  for module in self.modules:
		    if len(self.modules[module]['object'].outgoingMessageQueue) > 0:
		       self.debug("mainLoop: sending messages in queue for " + module)

		       data = self.modules[module]['object'].outgoingMessageQueue.pop()
		       dataComponents = data.split(":")
		       service = dataComponents[0]
		       screenName = dataComponents[1]
		       message = ":".join(dataComponents[2:])
		       self.sendMessage(service, screenName, message)


      def sendMessage(self,service,screenName,message):
	  self.debug("sendMessage: sending message - " + service + ": " + screenName + " - " + message)
	  self.myBot.sendMessage(screenName,message)	  

      def handleMessage(self,data):
	  if len(data) > 0:
	     service, screenName, messageWords = self.splitMessageData(data)
	     
	     cmd = string.lower(messageWords[0])

	     if cmd == "help" or cmd == "?":
		self.sendMessage( service,screenName,self.printIMSHelp() )
	     elif cmd == "modules":
		self.sendMessage( service,screenName,self.printIMSModulesList() )
	     elif cmd == "about":
	        self.sendMessage( service,screenName,self.printIMSAbout() )
	     elif cmd == "whoami":
	        self.sendMessage( service,screenName,self.printIMSWhoAmI(screenName) )
	     elif cmd == "mode":
	        self.sendMessage( service,screenName,self.handleMode(screenName, messageWords) )
	     else:
		self.debug("handleMessage: no action found to handle '" + messageWords[0] + "'")
		self.sendMessage( service, screenName, "i'm sorry, i don't understand -- try 'help' or '?'")

	  else:
	     self.debug("handleIMSMessage: no message to handle!")	

      def handleMode(self, screenName, messageWords):
	  modeStr = ""   

	  if self.presences.has_key(string.upper(screenName)):
	     myPres = self.presences[string.upper(screenName)]

	     if len(messageWords) > 1:
	        # if the message sent was "mode off", then turn mode handling off
		if string.lower(messageWords[1]) == "off":
		   # switch mode to OFF
		   self.debug("switching mode to OFF for " + screenName)
		   myPres.modeEnabled = 0
		   myPres.modeCurrent = ""

		# else if the message they've sent is "mode $modulename" then enable 
		# mode handling for that module
		else:
			if self.findModuleByTrigger(messageWords[1]):
			   # switch mode to whatever module they've chosen
			   self.debug("switching mode to " + messageWords[1] + " for " + screenName)
			   modeStr = modeStr + "\nChanging mode to " + messageWords[1]
			   myPres.modeEnabled = 1
			   myPres.modeCurrent = string.lower(messageWords[1])
			else:
			   modeStr = modeStr + "\nCould not find suitable module for " + messageWords[1]

	     if myPres.modeEnabled == 1:
		currentMode = myPres.modeCurrent
		modeStr = modeStr + "\nCurrent Mode: " + str(myPres.modeCurrent)
	     else:
		modeStr = modeStr + "\nCurrent Mode: Off"

	  else:
		modeStr = modeStr + "\nYou do not have an existing presence with me."

	  return modeStr

      def printIMSHelp(self):
	  helpStr = ""
	  helpStr = helpStr + "\n" + self.name + " v" + self.version
	  helpStr = helpStr + "\ncommands:"
	  helpStr = helpStr + "\nhelp    - this help"
	  helpStr = helpStr + "\nabout    - about " + self.name
	  helpStr = helpStr + "\nmodules - list of modules"
	  helpStr = helpStr + "\nwhoami - information about you"
	  helpStr = helpStr + "\nmode - mode stuff"
	  helpStr = helpStr + "\n$modulename help - modulename help"

	  return helpStr


      def printIMSWhoAmI(self,screenname):
	  if self.presences.has_key(string.upper(screenname)):
		myPres = self.presences[string.upper(screenname)]
		initTime = myPres.initTime
		lastMessage = myPres.messageLog[len(myPres.messageLog)-1]

		meStr = ""
		meStr = meStr + "\nGreetings, " + screenname	     
		meStr = meStr + "\nWe initiated this current conversation at " + str(time.ctime(myPres.initTime))
		meStr = meStr + "\nThe last thing you said was:"
		meStr = meStr + "\n" + myPres.messageLog[len(myPres.messageLog)-1]
	  else:
		meStr = ""
		meStr = meStr + "\nI don't think I've spoken to you before!"
		meStr = meStr + "\nTry having a conversation with me, and then I'll tell you about yourself :) "

	  return meStr

      def printIMSModulesList(self):
	  moduleList = "\n" + self.name + " v" + self.version 
	  moduleList = "\nregistered modules:"
	  for module in self.modules:
	      moduleList = moduleList + "\n" + self.modules[module]['object'].name

	  moduleList = moduleList + "\ntry '$module help' for specific help"  
	  return moduleList

      def printIMSAbout(self):
	  aboutStr = ""
	  aboutStr = aboutStr + "\n" + self.name 
	  aboutStr = aboutStr + "\n" + self.desc
	  aboutStr = aboutStr + "\nver:" + self.version + " date:" + self.date
	  aboutStr = aboutStr + "\nby " + self.author
	  aboutStr = aboutStr + "\n" + self.url
	  return aboutStr

									     
# if this file is run directly
#if __name__ == "__main__":
#   
#   # create the bot, specify some AIM account to use
#   bot = MyBot("HotGayWhale","nerma")
#
#   try:
#      bot.go()
#   except bot.logonNickPassError:
#	  imserror(bot.logonNickPassError)

x = InstantManservant()
 










