# moduptime.py for instant manservant
# 04.15.2002
# copyright ben wilson, 2002-INFINITY

# example module for instant manservant

import time, os
from string import lower,strip

# each module needs a class called "IMSModule"
class IMSModule:

      def __init__(self):

	  #each module also should have a name, desc, version, date
	  #author, and URL
	  self.name = "dict"
	  self.desc = "simple module to remember and forget word/definition pairs"
	  self.version = "0.01"
	  self.date    = "04.23.2002"
	  self.author  = "ben wilson"
	  self.url     = "http://thelocust.org/projects/ims"
	  
	  self.rememList = {}	  
	  self.rememList['me'] = "mod" + self.name + " for ims! " + self.url

	  self.running = 0
	  self.debug_on = 1

	  # each module also has a "trigger word", which is 'registered' with
	  # the IMS core.  so, when the core receives a message as such: 'uptime help',
	  # it knows who to give that command to
	  self.trigger = "dict"

	  self.actions = ("help","about","remember","forget","list")


	  # each module also has it's own incoming/outgoing message queues.
	  self.incomingMessageQueue = []	  
	  self.outgoingMessageQueue = []
	 
	  self.debug("initialization complete!")
	  self.running = 1	  

      def debug(self,text):
	  if self.debug_on == 1:
	  	  print self.name + ':' + str(text)	  

      def mainLoop(self):
	  self.debug("mainLoop: starting!")
	  while self.running == 1:
		time.sleep(0.5)
		if len(self.incomingMessageQueue) > 0:
		   self.handleMessage(self.incomingMessageQueue.pop())


      def handleMessage(self,data): 
	  self.debug("handling message - " + data)
	  dataComponents = data.split(":")

	  service = dataComponents[0]
	  screenName = dataComponents[1]
	  message = ":".join(dataComponents[2:])
	  
	  messageArray = message.split(" ")	  
	  
	  if lower(messageArray[0]) == self.trigger :

	     if len(messageArray) > 1:

		if lower(messageArray[1]) == 'help' :
		   self.debug("got request for help")
		   self.sendMessage(service,screenName,self.showHelp(message))  

		elif lower(messageArray[1]) == "about" :
		   self.debug("got request for about")
		   self.sendMessage(service,screenName,self.showAbout())  

		elif lower(messageArray[1]) == "list" :
		   self.debug("got request for list")
		   self.sendMessage(service,screenName,self.showList())  

		elif lower(messageArray[1]) == "forget" :
		   self.debug("got request to forget")
		   self.sendMessage(service,screenName,self.forgetWord(messageArray))  

		elif lower(messageArray[1]) == "remember" :
		   self.debug("got request to remember")
		   self.sendMessage(service,screenName,self.rememberWord(messageArray))  

	        else:
		   self.debug("got request for definition")
		   self.sendMessage(service, screenName, self.displayWord(messageArray))
	     else:
		self.debug("no command - showing help")
		self.sendMessage(service,screenName, self.showHelp(message))

	  else:
	     self.debug("this message - '" + data + "' - isn't for me") 

      def sendMessage(self,service,screenName,text):
	  self.outgoingMessageQueue.append(service + ":" + screenName + ":" + text)

      def showHelp(self,message):
	  helpText =  "\n" + self.name + " v" + self.version + " - help"
	  helpText = helpText + "\nlist - list the words remembered"
	  helpText = helpText + "\nremember - '" + self.trigger + " remember $word $definition'"
	  helpText = helpText + "\nforget - '" + self.trigger + " forget $word"
	  helpText = helpText + "\nabout - version message, etc"
	  helpText = helpText + "\nhelp - this help"
	  return helpText

      def showAbout(self):
	  aboutStr = ""
	  aboutStr = aboutStr + "\n" + self.name 
	  aboutStr = aboutStr + "\n" + self.desc
	  aboutStr = aboutStr + "\nver:" + self.version + " date:" + self.date
	  aboutStr = aboutStr + "\nby " + self.author
	  aboutStr = aboutStr + "\n" + self.url
	  return aboutStr

      def showList(self):
	  listStr = ""
	  listStr = listStr + "\nI have remembered the following:"
	  for item in self.rememList:
	      listStr = listStr + "\n" + item
	  listStr = listStr + "\n'" + self.trigger + " $word'"
	  return listStr

      def rememberWord(self, messageArray):
	  word = messageArray[2]
	  definition = " ".join(messageArray[3:])

	  if len(word) == 0:
	     return self.name + " is used as such: " + self.trigger + " $word $definition"

	  elif self.rememList.has_key( lower( word ) ):
	     return "i already know " + word + " as " + self.rememList[word] + ". try having me 'forget " + word + ", and try again"

	  elif len( definition ) == 0:
	     return "remem needs a definition for " + word + ". e.g. 'remem $word $definition'"
	  
	  else:
	     self.rememList[lower(word)] = definition
	     return "i have rememebered " + word + " as " + definition

      def forgetWord(self, messageArray):
	  word = messageArray[2]
      
	  if len(word) == 0:
	     return "i need a word to forget! e.g. 'remem forget $word'"
	  elif self.rememList.has_key( lower(word) ):
	     del self.rememList[lower(word)]
	     return "i have forgotten " + word
	  else:
	     return "i do not have " + word + " in my memory!"

      def displayWord(self, messageArray):
	  word = messageArray[1]

	  if len(word) == 0:
	     return "you really should specify a word for me to lookup. e.g. " + self.trigger + " $word"
	  elif self.rememList.has_key( lower(word) ):
	     return self.rememList[word]
	  else:
	     return "i don't have a definition for " + word + ". you could have me remember one! e.g. " + self.name + " remember $word $definition"
	     





