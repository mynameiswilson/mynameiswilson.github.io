# TocBot v0.2
# date: 2002.08.21
# ben@thelocust.org
# http://thelocust.org/projects/ims
#
# the IMS implementation of the toc.py AIM bot class.  for IMS, it only needs a messageQueue list
# each message in the queue is just a string like such - "service:screenname:message"
# right now, the only service supported is AIM, so messages should be as such -
# "AIM:screenname:hello! how are you!"

from toc import TocTalk
import os, re 

class TocBot(TocTalk):

      import string

      messageQueue = []

      #whenever someone IMs us
      def on_IM_IN(self,data):
	  self.queueMessage(data)
						  
      def queueMessage(self,data):
	  dataComponents = data.split(":")
	  screenname = dataComponents[0]
	  message = self.strip( ":".join(dataComponents[2:]) )
	  self.messageQueue.append('AIM:' + screenname + ':' + message)

      def queueLength(self):
          return len(self.messageQueue)	


      def sendMessage(self,screenname,message):
	  self.do_SEND_IM(screenname, message)

      def strip(self,data):
	  return re.sub("<[^>]*>","",data)

      def shutdown(self):
	  self._running = 0


