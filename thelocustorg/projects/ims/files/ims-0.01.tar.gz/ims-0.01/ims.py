#!/usr/bin/python
# paim v0.1
#
# requires Py-TOC
# http://jamwt.com/Py-TOC/
from toc import TocTalk
from string import upper
import os.path
import string
from threading import Thread


import sgmllib, string

#oh, this will strip HTML, or really any XML, i guess
#from a string.  AIM for Windows sends in HTML (joy!)
class StrippingParser(sgmllib.SGMLParser):

    # These are the HTML tags that we will leave intact
    valid_tags = ('b', 'a', 'i', 'br', 'p')

    from htmlentitydefs import entitydefs # replace entitydefs from sgmllib
    
    def __init__(self):
        sgmllib.SGMLParser.__init__(self)
        self.result = ""
        self.endTagList = [] 
        
    def handle_data(self, data):
        if data:
            self.result = self.result + data

    def handle_charref(self, name):
        self.result = "%s&#%s;" % (self.result, name)
        
    def handle_entityref(self, name):
        if self.entitydefs.has_key(name): 
            x = ';'
        else:
            # this breaks unstandard entities that end with ';'
            x = ''
        self.result = "%s&%s%s" % (self.result, name, x)
    
    def unknown_starttag(self, tag, attrs):
        """ Delete all tags except for legal ones """
        if tag in self.valid_tags:       
            self.result = self.result + '<' + tag
            for k, v in attrs:
                if string.lower(k[0:2]) != 'on' and string.lower(v[0:10]) != 'javascript':
                    self.result = '%s %s="%s"' % (self.result, k, v)
            endTag = '</%s>' % tag
            self.endTagList.insert(0,endTag)    
            self.result = self.result + '>'
                
    def unknown_endtag(self, tag):
        if tag in self.valid_tags:
            self.result = "%s</%s>" % (self.result, tag)
            remTag = '</%s>' % tag
            self.endTagList.remove(remTag)

    def cleanup(self):
        """ Append missing closing tags """
        for j in range(len(self.endTagList)):
                self.result = self.result + self.endTagList[j]    
        


# the AIM bot class.  for IMS, it only needs a messageQueue list
# each message in the queue is just a string like such - "service:screenname:message"
# right now, the only service supported is AIM, so messages should be as such -
# "AIM:screenname:hello! how are you!"
class TocBot(TocTalk):
      import string

      messageQueue = []

      #whenever someone IMs us
      def on_IM_IN(self,data):
	  self.queueMessage(data)
						  
      def queueMessage(self,data):
	  dataComponents = data.split(":")
	  screenname = dataComponents[0]
	  message = self.strip( ":".join(dataComponents[2:]) )
	  self.messageQueue.append('AIM:' + screenname + ':' + message)

      def queueLength(self):
          return len(self.messageQueue)	


      def sendMessage(self,screenname,message):
	  self.do_SEND_IM(screenname, message)

      def strip(self,s):
	  """ Strip illegal HTML tags from string s """
	  parser = StrippingParser()
	  parser.feed(s)
	  parser.close()
	  parser.cleanup()
	  return parser.result



class InstantManservant:

      errors = {}
      modules = {}
      errors['NoConfigFile'] = "config file ims.conf not found!"
      errors['NoConfigScreenname'] = "you need a screenname in the config file!"
      errors['NoConfigPasswd'] = "you need a password in the config file!"

      def __init__(self):
	  self.debug_on = 1
	  self.configs = self.readConfig()
	  self.debug(self.configs)
	  
	  self.debug("init: checking configs")
	  self.checkConfig()

	  self.debug("init: initializing bots")
	  self.initBot()

	  self.debug("init: registering modules")
	  self.registerModules()

	  self.debug("init: entering mainLoop")
	  self.mainLoop()

      def __del__(self):
	  self.debug("shutting down bot thread!")
	  self.myBotThread.join()
	  for module in self.modules:
	      self.debug("stopping module " + module)
	      self.modules[module]['object'].running = 0
	      self.debug("stopping thread " + module)
	      self.modules[module]['thread'].join()

      def debug(self,text):
	   if (self.debug_on == 1):
		print("IMS DEBUG: " + str(text))
	         
      def throwError(self,text):
	  if __name__ != "__main__":
	     raise self.errors[text]
	  try:	  
		  print "IMS ERROR: " + self.errors[text]
		  self.debug(text + " - " + self.errors[text])
          except KeyError:
		 print "IMS ERROR: " + text

      #parse the config file.  currently, we are only looking for ims.conf
      def readConfig(self):
          #parse that config file!

          config_file = "ims.conf"
          ConfigError = "Config File " + config_file + " NOT FOUND!"

          # import python's native Configuration Parser
          import ConfigParser
          configs = {}

          # try to open the config file
          if(os.path.isfile(config_file)):
		myparser = ConfigParser.ConfigParser()  # start an instance of the config parser
                myparser.read(config_file)              # read in the config file named above in config_file

                temp = {}

		self.debug("readConfig: starting parse")
                for section in myparser.sections():     # for each section

		    self.debug("readConfig: parsing " + section)

		    for option in myparser.options(section):    # and each option for each section
			self.debug("readConfig: found " + option + " in " + section)
			temp[option] = myparser.get(section,option)
			
			self.debug("readConfig: " + option + "=" + temp[option])			

                    configs[section] = temp      # assign a dictionary entry in the dictionary 'configs'
                    temp = {}

          # otherwise raise an Error
          else:
		raise ConfigError                       # no Config file?  bombs away!

          # return the "configs" list, which is a big ol' multidimensional config array
          return configs

      # check the configuration file for the goodness.
      # at the moment, it only checks for a screename and password.
      def checkConfig(self):
	  if ( len ( string.strip( self.configs['ims']['screenname'] ) ) == 0 ):
	     self.throwError("NoConfigScreenname")
	  if ( len ( string.strip( self.configs['ims']['password'] ) ) == 0 ):
	     self.throwError("NoConfigPasswd")


      # start the service bot -- at the moment, it's only TOC (AIM), however, in the future
      # IMS will hopefully support any number of services.
      def initBot(self):
	  self.myBot = TocBot(self.configs['ims']['screenname'],self.configs['ims']['password'])
	  
	  self.debug("iniBot: starting thread!")
          self.myBotThread = Thread(target=self.myBot.go)
	  self.myBotThread.start()

      def registerModules(self):
          for section in self.configs:
	      if section[0:3] == 'mod':
		 self.debug("registerModules: found " + section)
                 try:
			modActive = self.configs[section]['active']
			if modActive == '1' or modActive == 1:
			   self.debug("registerModules: " + section[3:] + " is ACTIVE ")

			   #add this module to the modules listing
			   self.modules[section] = {}

			   #import the module
			   self.debug("registerModules: attempting import of " + section + ".py!")
			   try:
				exec('import ' + section)
				self.debug("registerModules: import of " + section + " successful!")
			   except ImportError:
				self.throwError(section + '.py does not exist! module not loaded')
			   

			   #create an object with the module in it.
			   exec('self.modules[section]["object"] = ' + section + '.IMSModule()')

			   #start a thread with the modules mainLoop in it
			   self.modules[section]["thread"] = Thread(target=self.modules[section]["object"].mainLoop)
			   self.modules[section]["thread"].start()


			else:
			   self.debug("registerModules: " + section + " is INACTIVE")
		 except NameError:
			self.debug("registerModules: " + section + " has no ACTIVE tag, considering inactive")

      def findModuleByTrigger(self, trigger):
	  self.debug("findModuleByTrigger: trying to find Module for '" + trigger + "'")
	  if len(trigger) > 0:
                result = ""
		for key in self.modules:
		    if self.modules[key]['object'].trigger == trigger:
		       result = key
		       return result
		if len(result) == 0:
		       return ""
	  else:
		return ""

      # takes the raw message data and returns the service, screenName and message split by
      # spaces into an array
      def splitMessageData(self,data):
	  dataComponents = data.split(":")
	  service = dataComponents[0]
	  screenName = dataComponents[1]
	  message = ":".join(dataComponents[2:])
	  messageWords = message.split(" ")
		
	  return service,screenName, messageWords

      def mainLoop(self):
	  self.debug("mainLoop: ENTERING!")
	  while 1:
		if self.myBot.queueLength() > 0:
		   data = self.myBot.messageQueue.pop()
		   self.debug("mainLoop: myBot message queue length " + str(self.myBot.queueLength()) ) 
		   self.debug("mainLoop: myBot message - " + data)
		   dataComponents = data.split(":")
		   service = dataComponents[0]
		   screenName = dataComponents[1]
		   message = ":".join(dataComponents[2:])
		   messageWords = message.split(" ")
		   
		   self.debug("mainLoop: finding handler for " + messageWords[0])	
		   handlerModule = self.findModuleByTrigger(messageWords[0])

		   if handlerModule == "":
		      self.debug("mainLoop: didn't find a module, attempting to answer it ourselves")
		      self.handleMessage(data)
		   else:
		      self.debug("mainLoop: found handler " + str(handlerModule) )
		      self.debug("mainLoop: appending message to " + handlerModule + "'s incoming message queue ")
		      self.modules[handlerModule]['object'].incomingMessageQueue.append(data)

		for module in self.modules:
		    if len(self.modules[module]['object'].outgoingMessageQueue) > 0:
		       self.debug("mainLoop: sending messages in queue for " + module)

		       data = self.modules[module]['object'].outgoingMessageQueue.pop()
		       dataComponents = data.split(":")
		       service = dataComponents[0]
		       screenName = dataComponents[1]
		       message = ":".join(dataComponents[2:])
		       self.sendMessage(service, screenName, message)

      def sendMessage(self,service,screenName,message):
	  self.debug("sendMessage: sending message - " + service + ": " + screenName + " - " + message)
	  self.myBot.sendMessage(screenName,message)	  

      def handleMessage(self,data):
	  if len(data) > 0:
	     service, screenName, messageWords = self.splitMessageData(data)
	     
	     cmd = string.lower(messageWords[0])

	     if cmd == "help" or cmd == "?":
		self.sendMessage( service,screenName,self.printIMSHelp() )
	     elif cmd == "modules":
		self.sendMessage( service,screenName,self.printIMSModulesList() )
	     else:
		self.debug("handleMessage: no action found to handle '" + messageWords[0] + "'")
		self.sendMessage( service, screenName, "i'm sorry, i don't understand -- try 'help' or '?'")

	  else:
	     self.debug("handleIMSMessage: no message to handle!")	

      def printIMSHelp(self):
	  return "InstantManservant Help!\nCommands: \nhelp - this help\nmodules - list modules\n$modulename help - module specific help"

      def printIMSModulesList(self):
	  moduleList = "\nRegistered Modules:"
	  for module in self.modules:
	      moduleList = moduleList + "\n" + self.modules[module]['object'].name

	  moduleList = moduleList + "\ntry '$module help' for specific help"  
	  return moduleList
									     
# if this file is run directly
#if __name__ == "__main__":
#   
#   # create the bot, specify some AIM account to use
#   bot = MyBot("HotGayWhale","nerma")
#
#   try:
#      bot.go()
#   except bot.logonNickPassError:
#	  imserror(bot.logonNickPassError)

x = InstantManservant()
 










